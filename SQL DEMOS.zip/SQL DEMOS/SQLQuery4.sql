Select *from Customer

Select *from STUDENT_174780
 select *from DNStudent



 CREATE TABLE HStudents
 (
 StudentID int primary key,
 StudentName varchar(20),
 Qualifaction varchar(30) check(Qualifaction in('BE','ME')),
 City varchar(20) check(City in('Mumabi','Pune','Chennai','Hyderabad')),
 )
  select *from HStudents


 CREATE TABLE SMarks 
 (
 MarksID int primary key,
 StudentId int foreign key (StudentID)references Students(StudentID),
 Marks1 int,
 Marks2 int,
 Marks3 int
 )

  select *from SMarks

  CREATE PROCEDURE insertVSTUDENT_174780

  @StudentID int,
  @StudentName varchar(20),
  @Qualifaction varchar(30),
  @City varchar(20)
  AS
  BEGIN
  INSERT INTO HStudents VALUES(@StudentID,@StudentName,@Qualifaction,@City)
  END

  select *from insertVSTUDENT_174780


   CREATE PROCEDURE DeleteVSTUDENT_174780

  @StudentID int
    AS
  BEGIN
  Delete from  HStudents where  StudentID=@StudentID
  END

  CREATE PROCEDURE SearchVSTUDENT1_174780

  @StudentID int
    AS
  BEGIN
  select *from  HStudents where  StudentID=@StudentID
  END
   select *from HStudents