CREATE DATABASE TRAINING_174780

create table Staff_Master_174780
(
Staff_Code int primary key,
Staff_Name varchar(30),
Des_Code int,
Dept_Code int,
Staff_dob DateTime,
Hiredate DateTime,
Mgr_code int,
Salary numeric,
Address varchar(50)
)

insert into Staff_Master_174780 values(1,'Harshitha',201,01,'1995/11/26','2019/02/20',001,40000,'Mumbai')
insert into Staff_Master_174780 values(2,'Bharath',202,02,'1996/01/04','2019/02/12',002,56000,'Pune')
insert into Staff_Master_174780 values(3,'Naveen',203,03,'1997/12/12','2019/12/20',003,60000,'Hyderbad')
insert into Staff_Master_174780 values(4,'Gopi',204,04,'1998/12/07','2019/05/23',004,70000,'Mumbai')
insert into Staff_Master_174780 values(5,'Satya',205,05,'1994/03/07','2019/07/08',005,50000,'Pune')
insert into Staff_Master_174780 values(6,'Akhila',206,06,'1993/07/08','2019/02/24',006,60000,'Hyderbad')

select *from Staff_Master_174780

drop table