Create table FlightBooking_174780
(
PassportID int primary key,
FisrtName varchar(30),
LastName  varchar(30),
Bording Datetime,
Destination varchar(20),
price numeric,
Creditcard nvarchar(20)
)
go
create proc udp_getflightbooking_174780
as
begin
select * from FlightBooking_174780
end
go

go
create proc udp_getbookbyid(@id int)
as
begin
select * from books where bookid=@id
end
go

go
create proc udp_insertbook(@name varchar(50),
@author varchar(50),@price float)
as
begin
insert into books(bookname,author,price) 
values(@name,@author,@price)
end 
go

go
create proc udp_updatebook(@name varchar(50)
,@author varchar(50),@price float,@id int)
as
begin
update Books set bookname= @name, author=@author, 
price = @price where bookid=@id
end 
go

go
create proc udp_deletebook(@id int)
as
begin
delete from books where bookid=@id
end 
go

exec udp_getbooks

insert into Books(bookname,author,price)
values ('Asp.Net MVC','Scott Hansleman',1234.88)