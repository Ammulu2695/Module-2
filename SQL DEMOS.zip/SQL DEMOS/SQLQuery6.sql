CREATE TABLE Employee1
(
 empno int primary key,   
 empname varchar(50) not null,   
 empsal numeric(10,2) check(empsal >= 25000) , 
 emptype varchar(1) check(emptype in('C','P'))
 ) 

 go 
 create proc VGetEmployeeByID
 (@eno int ) as 
 select * from Employee1 where empno = @eno 
  go 
 HGetEmployeeByID 153

 CREATE PROC VGetEmployeeByID_174780_delete
 (@eno int)
 as
 delete from Employee1
 where empno =@eno
 go
 select * from Employee1