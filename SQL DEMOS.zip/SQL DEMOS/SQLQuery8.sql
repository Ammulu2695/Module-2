create table customer_174780 
( 
 customerid int identity primary key,  
 customername varchar(50),  
 city varchar(30),  
 creditlimit numeric(10,2)
  ) 
 insert into customer_174780 values ('harshitha','Pune',54545)
 insert into customer_174780 values ('vaddineni','Pune',52369)
 insert into customer_174780 values ('adbfd','Pune',9862)
 insert into customer_174780 values ('erfg','hyd',451552)
 insert into customer_174780 values ('ertgdf','Mumbai',787456)
 insert into customer_174780 values ('bfgxd','Mumbai',54874)

 create table SSuppler_174780
 (
  SupplierId  int primary key, 
  Suppliername varchar(50), 
  City varchar(30), 
  ContactNo real,
  CreditBalance real 
  )
   insert into SSuppler_174780 values (123,'bharath','Pune',9786543289,54545)
   insert into SSuppler_174780 values (124,'Naveen','Pune',4523698712,789653)
    insert into SSuppler_174780 values (125,'Akhila','hyd',4523698720,852369)
   insert into SSuppler_174780 values (126,'Gopi','Mumbai',2369854752,025896)
   insert into SSuppler_174780 values (128,'Anveesh','hyd',8963521478,78963)
   	insert into SSuppler_174780 values (129,'Satya','hyd',7842380600,896532)
