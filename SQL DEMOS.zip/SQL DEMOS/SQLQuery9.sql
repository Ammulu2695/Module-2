Create table Categoriess_174780
(
cId int primary key,
cName varchar(20),
)

Create table Products_174780
(
pId int primary key,
pName varchar(20),
cId int
)

insert into Categoriess_174780 values(123,'harshitha')
insert into Categoriess_174780 values(124,'vaddineni')
insert into Categoriess_174780 values(125,'bharath')
insert into Categoriess_174780 values(126,'gopi')
insert into Categoriess_174780 values(127,'satya')
insert into Categoriess_174780 values(128,'anveesh')
insert into Categoriess_174780 values(129,'naveen')
insert into Categoriess_174780 values(130,'akhila')



insert into Products_174780 values(234,'harshitha',123)

select * from Categoriess_174780

select * from Products_174780