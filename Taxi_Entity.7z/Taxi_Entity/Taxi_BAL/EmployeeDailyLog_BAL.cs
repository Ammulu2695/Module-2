﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;
using System.Data.SqlClient;

namespace Taxi_BAL
{
    public class EmployeeDailyLog_BAL
    {
        //Validating Data for EmployeeRoster
        public static bool ValidateLog(EmployeeRoster employeeRoster)
        {
            bool validlog = true;
            StringBuilder sb = new StringBuilder();
            if ((DateTime.Parse(employeeRoster.FromDate) != DateTime.Today)|| employeeRoster.FromDate==string.Empty)
            {
                validlog = false;
                sb.Append(Environment.NewLine + " You can enter log for Todays date only ");

            }

            if((double.Parse(employeeRoster.InTime)>24)|| employeeRoster.FromDate == string.Empty)
            {
                validlog = false;
                sb.Append(Environment.NewLine + " Time can be uptill 24 hours format");

            }

            if ((double.Parse(employeeRoster.OutTime)< double.Parse(employeeRoster.InTime)) || (double.Parse(employeeRoster.OutTime)>24)|| employeeRoster.OutTime == string.Empty)
            {
                validlog = false;
                sb.Append(Environment.NewLine + " Out Time Shoule be greater than In Time  and less than 24 hours");

            }
            if (!validlog)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }

            return validlog;
        }

        //Once validation is done sending data to DAL

        public static bool AddEmployeeLogBAL(EmployeeRoster employeeRoster)
        {
            bool logadded = false;
            try
            {
                if (ValidateLog(employeeRoster))
                {
                    EmployeeDailyLog_DAL employeeDailyLog_DAL = new EmployeeDailyLog_DAL();
                    logadded = employeeDailyLog_DAL.AddEmployeeLogDAL(employeeRoster);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return logadded;
        }


    }
}
