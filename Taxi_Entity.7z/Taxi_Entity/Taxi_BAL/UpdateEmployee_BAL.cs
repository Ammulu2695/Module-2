﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Taxi_BAL
{
   public class UpdateEmployee_BAL
    {
        // Validating Employee

        public static bool ValidateUpdatedEmployee(Employee employee)
        {
            bool validemployee = true;
            StringBuilder sb = new StringBuilder();
           

            //Checking Employee Name IS Specified
            Regex regex1 = new Regex(@"^[a-zA-Z]+$");

            if ((!regex1.IsMatch(employee.EmployeeName))||(string.IsNullOrEmpty(employee.EmployeeName)))
            {
                 validemployee = false;
                sb.Append(Environment.NewLine + "Employee Name should be letters only ");
            }
          

           
            //Checking Phone Number is 10 digits
            Regex regex3 = new Regex(@"^[0-9]{10}$");
            if ((!regex3.IsMatch(employee.PhoneNumber))||(string.IsNullOrEmpty(employee.PhoneNumber)))
            {
                 validemployee = false;
                sb.Append(Environment.NewLine + "Employee PhoneNumber should be 10 digits and cannot be empty");
            }

            //Checking EmailID
            Regex regex4 = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if ((!(regex4.IsMatch(employee.EmailID)))||string.IsNullOrEmpty(employee.EmailID))
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Employee EmailID should be in format xxx@xxx.xxx and cannot be blank");
            }

            //Checking Driving Lisence Number
            Regex regex5 = new Regex(@"^[A-Za-z0-9]{4,9}$");
            if( (!(regex5.IsMatch(employee.DirvingLicenseNumber)))||(string.IsNullOrEmpty(employee.DirvingLicenseNumber)))
            {
                 validemployee = false;
                sb.Append(Environment.NewLine + "Employee DirvingLicenseNumber should be alphanumeric , atleast 4 digits And atmost 9 digits and cannot be blank");
            }

            if (!validemployee)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }

            return validemployee;

        }


        //  Employee Data is sent to DAL 

        public static bool UpdateEmployeeBAL(Employee updateEmployee)
        {
            bool employeeupdated = false;
            try
            {
                if (ValidateUpdatedEmployee(updateEmployee))
                {
                    UpdateEmployee_DAL updateEmployee_DAL = new UpdateEmployee_DAL();
                    employeeupdated = updateEmployee_DAL.UpdateEmployeeDAL(updateEmployee);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return employeeupdated;
        }
    }
}
