﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;
using System.Data;

namespace Taxi_BAL
{
  public class SearchVehicle_BAL
    {
        // Sending Search Data to DAL

        SearchVehicle_DAL SearchVehicle = new SearchVehicle_DAL();

        public DataTable Display()
        {
            try
            {
                return SearchVehicle.Display();
            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch(SystemException ex2)
            {
                throw ex2;
            }
        }

    }
}
