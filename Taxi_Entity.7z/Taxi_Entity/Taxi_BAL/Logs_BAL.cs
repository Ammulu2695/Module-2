﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;
using System.Data.SqlClient;

namespace Taxi_BAL
{
   public class Logs_BAL
    {

        //Validating Employee Log

        public static bool ValidateEmployeeLog(EmployeeLogs employeeLogs)
        {
            bool validemployeelog = true;
            StringBuilder sb = new StringBuilder();


            //Checking Employee Password IS Specified
            if (string.IsNullOrWhiteSpace(employeeLogs.Password))
            {
                validemployeelog = false;
                sb.Append(Environment.NewLine + "Employee Password cannot be blank");
            }

            if (!validemployeelog)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }


            return validemployeelog;

        }

        //Once validation is done sending data to DAL

            public static bool AddEmployeeLogBAL(EmployeeLogs employeeLogs)
        {
            bool employeelogadded = false;
            try
            {
                if (ValidateEmployeeLog(employeeLogs))
                {
                    Logs_DAL  employeelogDal = new Logs_DAL();

                    employeelogadded = employeelogDal.AddEmployeeLogsDAL(employeeLogs);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return employeelogadded;
        }

        //Validating Customer Log


        public static bool ValidateCustomerLog(CustomerLogs customerLogs)
        {
            bool validCustomerlog = true;
            StringBuilder sb = new StringBuilder();


            //Checking Employee Password IS Specified
            if (string.IsNullOrWhiteSpace(customerLogs.Password))
            {
                validCustomerlog = false;
                sb.Append(Environment.NewLine + "Employee Password cannot be blank");
            }

            if (!validCustomerlog)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }


            return validCustomerlog;

        }

        //Once validation is done sending data to DAL

        public static bool AddCustomerLogBAL(CustomerLogs customerLogs)
        {
            bool customerlogadded = false;
            try
            {
                if (ValidateCustomerLog(customerLogs))
                {
                    Logs_DAL customerlogDal = new Logs_DAL();

                    customerlogadded = customerlogDal.AddCustomerLogsDAL(customerLogs);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return customerlogadded;
        }



    }
}
