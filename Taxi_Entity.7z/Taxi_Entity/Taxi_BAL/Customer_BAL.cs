﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using System.Data.SqlClient;
using System.Windows;

namespace Taxi_BAL
{
    public class Customer_BAL
    {
        //Validating Customer


        public static bool ValidateCustomer(Customer customer)
        {
            bool validcustomer = true;
            StringBuilder sb = new StringBuilder();


            //Checking Customer Name IS Specified
            if ((!(Regex.IsMatch(customer.CustomerName, @"^[a-zA-Z]+$"))) || customer.CustomerName == string.Empty)
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Customer Name should be in characters and cannot be blank ");
            }
            //Checking Phone Number is 10 digits
            Regex regex1 = new Regex(@"^[0-9]{10}$");
            if ((!regex1.IsMatch(customer.PhoneNumber) || (customer.PhoneNumber) == string.Empty))
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Employee PhoneNumber should be 10 digits ");
            }

            //Checking EmailID
            Regex regex2 = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if ((!(regex2.IsMatch(customer.EmailID))) || (customer.EmailID) == string.Empty)
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Employee EmailID should be in format xxx@xxx.xxx ");
            }



            //Checking Address
           
            if ( (customer.Address == string.Empty))
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Address cannot be blank");
            }


            if (!validcustomer)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }

            return validcustomer;

        }

        //Validating Booking Data

        public static bool ValidateBooking(Booking newbooking)
        {
            bool validDate = true;
            StringBuilder sb = new StringBuilder();


           

            //Checking Customer ID
            Regex regex3 = new Regex(@"^\d+$");
            if ((!regex3.IsMatch(newbooking.CustomerID.ToString()) || (newbooking.CustomerID.ToString()) == string.Empty))
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Customer ID should be digits Only");
            }



            if ( (!(Regex.IsMatch(newbooking.SourceAddress, @"^[a-zA-Z]+$"))) || newbooking.SourceAddress == string.Empty)
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Source Address should be  in Characters and cannot be blank ");
            }


            if( (!(Regex.IsMatch(newbooking.DestinationAddress, @"^[a-zA-Z]+$"))) || newbooking.SourceAddress == string.Empty)
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Destination Address should be in Characters and cannot be blank ");
            }

            if ((newbooking.TripStartDate < DateTime.Today))
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Trip Start Date Should be Current Date ");
            }

            if ((newbooking.TripEndDate < newbooking.TripEndDate)|| newbooking.TripEndDate.ToString()==string.Empty)
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Trip End Date Should be more than Trip Start Date  ");
            }

            if ((Int32.Parse(newbooking.StartTime) >24)|| (Int32.Parse(newbooking.StartTime) <0))
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Trip Start time Should be between 1 and 24 hrs only ");
            }

            if ((Int32.Parse(newbooking.EndTime) > 24) || (Int32.Parse(newbooking.EndTime) < 0))
            {
                validDate = false;
                sb.Append(Environment.NewLine + "Trip Start time Should be between 1 and 24 hrs only ");
            }

            if (!validDate)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }

            return validDate;

        }
        //Once validation is done sending data to DAL

        public static bool AddBoolkingBAL(Booking newbooking)
        {
            bool bookingdone = false;
            try
            {
                if (ValidateBooking(newbooking))
                {
                    Customer_DAL bookingDal=new Customer_DAL();
                    bookingdone = bookingDal.AddBookingDAL(newbooking);
                 }
}
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return bookingdone;
        }

        //Once validation is done sending data to DAL

        public static bool AddCustomerBAL(Customer newcustomer)
        {
            bool customeradded = false;
            try
            {
                if (ValidateCustomer(newcustomer))
                {
                    Customer_DAL customerDal = new Customer_DAL();
                    customeradded = customerDal.AddCustomerDAL(newcustomer);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return customeradded;
        }


        //Once validation is done sending data to DAL

        public int Auto()
        {
            Customer_DAL customer_DAL = new Customer_DAL();
            return customer_DAL.AutoMatic();
        }
    }
}  
