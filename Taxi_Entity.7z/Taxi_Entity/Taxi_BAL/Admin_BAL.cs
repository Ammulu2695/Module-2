﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace Taxi_BAL
{
    public class Admin_BAL
    {

        //Validating Employee
        public static bool ValidateEmployee(Employee employee)
        {
            bool validemployee = true;
            StringBuilder sb = new StringBuilder();


            //Checking Employee Name IS Specified
            if ((!(Regex.IsMatch(employee.EmployeeName, @"^[a-zA-Z]+$"))) || employee.EmployeeName == string.Empty)
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Employee Name should be  in Characters and cannot be blank ");
            }


            //Checking Phone Number is 10 digits
            Regex regex1 = new Regex(@"^[0-9]{10}$");
            if ((!regex1.IsMatch(employee.PhoneNumber)) || (employee.PhoneNumber) == string.Empty)
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Employee PhoneNumber should be 10 digits ");
            }

            //Checking EmailID
            Regex regex2 = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if (!(regex2.IsMatch(employee.EmailID)) || (employee.EmailID) == string.Empty)
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Employee EmailID should be in format xxx@xxx.xxx and cannot be blank");
            }

            //Checking Driving Lisence Number
            Regex regex3 = new Regex(@"^[A-Za-z0-9]{4,9}$");
            if (!(regex3.IsMatch(employee.DirvingLicenseNumber)) || (employee.DirvingLicenseNumber) == string.Empty)
            {
                validemployee = false;
                sb.Append(Environment.NewLine + "Employee DirvingLicenseNumber should be alphanumeric , atleast 4 digits And atmost 9 digits and cannot be blank");
            }

            //Checking Employee ID
            //Regex regex4 = new Regex(@"^\d+$");
            //if ((!regex4.IsMatch(employee.EmployeeID.ToString()) || (employee.EmployeeID.ToString()) == string.Empty))
            //{
            //    validemployee = false;
            //    sb.Append(Environment.NewLine + "Employee ID should be Single digit Only");
            //}

            ////Checking Taxi ID
            //Regex regex5 = new Regex(@"^\d+$");
            //if ((!regex5.IsMatch(employee.TaxiID.ToString()) || (employee.TaxiID.ToString()) == string.Empty))
            //{
            //    validemployee = false;
            //    sb.Append(Environment.NewLine + "Taxi ID should be digits Only");
            //}


            if (!validemployee)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }


            return validemployee;

        }

        //Once validation is done sending data to DAL


        public static bool AddEmployeeBAL(Employee newemployee)
        {
            bool employeeadded = false;
            try
            {
                if (ValidateEmployee(newemployee))
                {
                    Admin_DAL employeeDal = new Admin_DAL();
                    employeeadded = employeeDal.AddEmployeeDAL(newemployee);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return employeeadded;
        }

        //Once validation is done sending data to DAL

        Admin_DAL bookingReportDAL = new Admin_DAL();
        public DataTable Display()
        {
            try
            {
                DataTable dt = bookingReportDAL.DisplayDal();
                if(dt.Rows.Count<=0)
                {

                    throw new TaxiNotFoundException("No records Available");
                }
                return dt;
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

        }


    }
}


