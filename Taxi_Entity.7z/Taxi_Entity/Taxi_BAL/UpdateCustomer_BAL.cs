﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace Taxi_BAL


{
   public class UpdateCustomer_BAL
    {
        
        //Validating Customer
             public static bool ValidateUpdatedCustomer(Customer customer)
        {
            bool validcustomer = true;
            StringBuilder sb = new StringBuilder();
           

            //Checking Employee Name IS Specified
            if (string.IsNullOrWhiteSpace(customer.CustomerName))
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Employee Name cannot be blank");
            }


            //Checking Phone Number is 10 digits
            Regex regex1 = new Regex(@"^[0-9]{10}$");
            if (!regex1.IsMatch(customer.PhoneNumber)||(string.IsNullOrEmpty(customer.PhoneNumber)))
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Employee PhoneNumber should be 10 digits and cannot be blank ");
            }

            //Checking EmailID
            Regex regex2 = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if( (!(regex2.IsMatch(customer.EmailID)))||(string.IsNullOrEmpty(customer.EmailID)))
            {
                validcustomer = false;
                sb.Append(Environment.NewLine + "Employee EmailID should be in format xxx@xxx.xxx and cannot be blank ");
            }

            if (!validcustomer)
            {
                throw new TaxiNotFoundException(sb.ToString());
            }
            return validcustomer;

        }

        //  Customer Data is sent to DAL 


        public static bool UpdateCustomerBAL(Customer updateCustomer)
        {
            bool customerupdated = false;
            try
            {
                if (ValidateUpdatedCustomer(updateCustomer))
                {
                    UpdateCustomer_DAL updatCustomer_DAL = new UpdateCustomer_DAL();
                    customerupdated = updatCustomer_DAL.UpdateCustomerDAL(updateCustomer);
                }
            }
            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            return customerupdated;
        }
    }
}
