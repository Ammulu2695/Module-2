﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;


namespace Taxi_BAL
{
  public  class Employee_BAL
    {
        
    }
}
