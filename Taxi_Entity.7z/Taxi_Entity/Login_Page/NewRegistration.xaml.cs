﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Data.SqlClient;
using System.Configuration;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for NewRegistration.xaml
    /// </summary>
    public partial class NewRegistration : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        //SqlCommand Command;


        public NewRegistration()
        {
            InitializeComponent();
        }

           //Navigating to Pages depending on Request

        private void Login_Page_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginpage = new MainWindow();
            loginpage.Show();
           
        }

        private void btnaddcust_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Customer newcustomer = new Customer();
                newcustomer.CustomerID = Int32.Parse(txtCustomerID.Text);
                newcustomer.CustomerName = txtCustomerName.Text;
                newcustomer.PhoneNumber = (txtPhoneNumber.Text);
                newcustomer.EmailID = txtEmailID.Text;
                newcustomer.Address = txtAddress.Text;


                AddCustomerPL(newcustomer);

            }
            
            // If Exception  Occured
            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Adding Customer ");
            }
            catch (Exception)
            {
                MessageBox.Show(" Something went wrong ......Either ID already exists or Some fields are left blank or invalid entries");
            }

        }
        //Sendind Data to Respective Layers

        private static void AddCustomerPL(Customer newcustomer)
        {
            
            
                bool customeradded = Customer_BAL.AddCustomerBAL(newcustomer);


                // If true value is returned


                if (customeradded)
                {
                    MessageBox.Show(" Congratulations You are valid customer ");
                    LoginGenerationPage loginGeneration = new LoginGenerationPage();
                    loginGeneration.Show();
                }

                // If true value is not  returned


                else
                {
                    MessageBox.Show("OOPS!!! You are not yet regestered ");
                }
            

            


           
        }
    }
}
