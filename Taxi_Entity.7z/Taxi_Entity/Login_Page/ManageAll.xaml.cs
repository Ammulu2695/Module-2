﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for ManageAll.xaml
    /// </summary>
    public partial class ManageAll : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public ManageAll()
        {
            InitializeComponent();
        }
        DataTable datatable = null;

        //Searching Employee by ID on Click of button


        private void btnsearchemp_Click(object sender, RoutedEventArgs e)
        {
                try
                {
                    Employee employee = new Employee();
                    employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);
                    
                    con.ConnectionString = connStr;
                    con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;
                    string querry = "[netra].[SPsearchEmpById]";
                    Command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
                Command.CommandText = querry;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                SqlDataReader reader = Command.ExecuteReader();

                //If database has value

                if (reader.HasRows)
                     {
                    datatable = new DataTable();
                    datatable.Load(reader);
                    MessageBox.Show("Searched Result Successful");
                    
                     }

                //If database does not have value

                else
                {
                    MessageBox.Show("Searched Result Not Found");
                }

                }
            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Employee Search");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            
        }

        LoadGrid();
        }
        //Displaying the data

        public void LoadGrid()
        {
            //SqlConnection connection = new SqlConnection();

            try
            {
                //Employee employee = new Employee();
                //employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = con;
                Employee employee = new Employee();
                string query = "SELECT *FROM  [netra].[Employee]";
                //command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgmanageallemp.DataContext = Table;


            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // dgmanageallemp.ItemsSource = dt.DefaultView;
            //dgmanageallemp.DataContext = datatable;
           


        }
              //Deleting Employee by ID on Click of button

        private void btndeleteemp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee employee = new Employee();
                employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;
                string query = "[netra].[SPdeleteEmpById]";
                Command.Parameters.AddWithValue("@EmployeeID", employee.EmployeeID);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfDeleted = Command.ExecuteNonQuery();
                //If Command got executed 
                if (NumberOfDeleted == 1)
                {
                    MessageBox.Show("Employee Details Deleted Successfully");
                }
                else
                //If Command does not  executes

                {
                    MessageBox.Show("Failed to delete Employee");
                }


                //if (reader.HasRows)
                //{
                //    datatable = new DataTable();
                //    datatable.Load(reader);
                //    MessageBox.Show(" Employee Details Deleted");

                //}
                //else
                //{
                //    MessageBox.Show("Employee Details Not Deleted");
                //}
            }
            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Employee Search");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
                LoadGrid();
        }
        //Sending Data to respective  Layers

        private void btnupdateemp_Click(object sender, RoutedEventArgs e)
        {
          
            UpdateEmployee updateEmployee = new UpdateEmployee();
            updateEmployee.Show();
        }

        private void BackToAdminDetails_Click(object sender, RoutedEventArgs e)
        {
            AdminDetailsPage adminDetailsPage = new AdminDetailsPage();
            adminDetailsPage.Show();
        }
    }
    }

