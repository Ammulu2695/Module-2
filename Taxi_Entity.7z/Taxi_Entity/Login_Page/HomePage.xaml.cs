﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }

       
        private void Login_Page_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginpage = new MainWindow();
            loginpage.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SearchAvailableVehicle searchpage = new SearchAvailableVehicle();
            searchpage.Show();
            this.Close();
        }



        private void btncustomer_MouseMove(object sender, MouseEventArgs e)
        {
            CustomerDetailsPage customerpage = new CustomerDetailsPage();
            customerpage.Show();
            this.Close();
            
        }

        private void btnemployee_MouseMove(object sender, MouseEventArgs e)
        {
            EmployeeDetailsPage employeepage = new EmployeeDetailsPage();
            employeepage.Show();
            this.Close();

        }

        private void btnadmin_MouseMove(object sender, MouseEventArgs e)
        {
            AdminPasswordPage passwordPage = new AdminPasswordPage();
            passwordPage.Show();
            this.Close();

        }
    }
}
