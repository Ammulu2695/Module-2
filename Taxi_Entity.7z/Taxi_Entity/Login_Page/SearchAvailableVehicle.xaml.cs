﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_BAL;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;
using System.Data;


namespace Login_Page
{
    /// <summary>
    /// Interaction logic for SearchAvailableVehicle.xaml
    /// </summary>
    public partial class SearchAvailableVehicle : Window
    {
        public SearchAvailableVehicle()
        {
            InitializeComponent();
        }


        //Navigating to Pages depending on Request

        private void BackToPage_Click(object sender, RoutedEventArgs e)
        {
            BookingPage bookingPage = new BookingPage();
            bookingPage.Show();
            this.Close();
        }
        //Navigating to Pages depending on Request

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SearchVehicle_DAL searchVehicle = new SearchVehicle_DAL();
             DataTable table = searchVehicle.Display();
              dgTaxi.ItemsSource = table.DefaultView;
        }
        //Navigating to Pages depending on Request


        private void BackToPageHome_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
        }
    }
}
