﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for UpdateEmployee.xaml
    /// </summary>
    public partial class UpdateEmployee : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public UpdateEmployee()
        {
            InitializeComponent();
        }

       //Displaying Updated data into LoadGrid

        public void LoadGrid()
        {
            //SqlConnection connection = new SqlConnection();

            try
            {
                //Employee employee = new Employee();
                //employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = con;
                string query = "SELECT * FROM  [netra].[Employee]";
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgUpdateemp.DataContext = Table;


            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

            private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        //Sending Data to respective Layers for Validations and Updating to database

        private void btnsubmit_Click_1(object sender, RoutedEventArgs e)
        {
                Employee updateEmployee = new Employee();

                try
                {
                    updateEmployee.EmployeeID=Int32.Parse(txtupdateid.Text);
                    updateEmployee.EmployeeName = txtupdempname.Text;
                    updateEmployee.TaxiID = Int32.Parse(txtupdempTaxiID.Text);
                    updateEmployee.PhoneNumber = txtupdempphnno.Text;
                    updateEmployee.EmailID = txtupdempemailid.Text;
                    updateEmployee.Address = txtupdempadd.Text;
                    updateEmployee.DirvingLicenseNumber = txtupdempdrvinglisence.Text;

                    bool employeeupdated = UpdateEmployee_BAL.UpdateEmployeeBAL(updateEmployee);

                // If true value is returned

                    if (employeeupdated)
                    {
                        MessageBox.Show(" Employees Details Updated");
                    }

                // If true value is not  returned


                else
                {
                        MessageBox.Show("OOPS!!! Error occured while Updating");
                    }

                    LoadGrid();
                }

            // If Exception  Occured


            catch (TaxiNotFoundException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (Exception)
                {
                    MessageBox.Show("All  fields are required");
                }
            
        }

        private void BacktoAdminDetails_Click(object sender, RoutedEventArgs e)
        {
            AdminDetailsPage adminDetailsPage = new AdminDetailsPage();
            adminDetailsPage.Show();
        }
    }
}
