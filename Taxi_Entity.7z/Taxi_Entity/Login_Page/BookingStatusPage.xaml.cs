﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;


namespace Login_Page
{
    /// <summary>
    /// Interaction logic for BookingStatusPage.xaml
    /// </summary>
    public partial class BookingStatusPage : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public BookingStatusPage()
        {
            InitializeComponent();
        }

        private void btncheck_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Booking booking = new Booking();
                booking.BookingID=Int32.Parse(txtstatbookingid.Text);
                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;

                //Checking if booking ID matches
                string querry = "Select BookingID from [netra].[Booking] where BookingID=@BookingID";
                Command.Parameters.AddWithValue("@BookingID",booking.BookingID);
              
                Command.CommandText = querry;

                SqlDataReader reader = Command.ExecuteReader();

                //If Database  have values

                if (reader.HasRows)
                {
                    MessageBox.Show("Your Booking Is Confirmed");
                }
                //If Database does not have values
                else
                {
                    MessageBox.Show("Your Booking is not Confirmed");
                }

            }
            //If Exception is occured

               catch (TaxiNotFoundException ex)
              {
                throw ex;
              }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            //Close Connection 
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

      
        private void CustomerDetails_Click(object sender, RoutedEventArgs e)
        {
            CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage();
            customerDetailsPage.Show();
        }
    }
}
