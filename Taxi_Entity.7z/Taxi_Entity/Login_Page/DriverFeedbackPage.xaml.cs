﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for DriverFeedbackPage.xaml
    /// </summary>
    public partial class DriverFeedbackPage : Window
    {
        static string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public DriverFeedbackPage()
        {
            InitializeComponent();
        }
        //Adding the Feedback

        private void btnsbtgiven_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Feedbacks feedbacks = new Feedbacks();
                feedbacks.CustomerID = Int32.Parse(txtcustidgiven.Text);
                feedbacks.EmployeeID = Int32.Parse(txtempidgiven.Text);
                feedbacks.Feedback = txtfeedbackgiven.Text;

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;

                string query = "[netra].[SPAddFeedback]";

                Command.Parameters.AddWithValue("@CustomerID", feedbacks.CustomerID);
                Command.Parameters.AddWithValue("@EmployeeID", feedbacks.EmployeeID);
                Command.Parameters.AddWithValue("@Feedback", feedbacks.Feedback);
                
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();

                //If value return is  true

                if (NumberOfRowsAdded == 1)
                {
                    MessageBox.Show("Your Feedback is Submitted");
                }
                //If value return is not true

                else
                {
                    MessageBox.Show("Error has occured  Feedback not Submitted.... Try Once Again");
                }
                   

            }
            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show( ex.Message,"Driver Feedback");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }

            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        //View The Feedback

        private void btnsbtview_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Feedbacks feedbacks = new Feedbacks();
               
                feedbacks.EmployeeID = Int32.Parse(txtempidview.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;


                string query = "netra.spgetFeedback";

                Command.CommandType = System.Data.CommandType.StoredProcedure;
                Command.CommandText = query;

                Command.Parameters.AddWithValue("@EmployeeID", feedbacks.EmployeeID);
                SqlDataReader Reader = Command.ExecuteReader();

                //If value return is true

                if (Reader.HasRows)
                {

                    while (Reader.Read())
                    {
                        txtempidview.Text = Reader[1].ToString();
                        txtfeedbackview.Text = Reader[2].ToString();
                       
                    }
                }

                //If value return is not true

                else
                {
                    MessageBox.Show("Feedback not found");
                }

            }
            //If Exception Occured

            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
           
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }




        }
    }
    
}
