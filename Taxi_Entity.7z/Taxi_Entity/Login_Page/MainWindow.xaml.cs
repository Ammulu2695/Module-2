﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Configuration;
using System.Data.SqlClient;



namespace Login_Page
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);



        public MainWindow()
        {
            InitializeComponent();
        }
        //Checking user type first and then if valid credentials are passed navigate to next Page

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            //NavigationService nav;
            //nav = NavigationService.GetNavigationService(this);
            //MainWindow nextpage = new MainWindow();
            //nav.Navigate(nextpage);

            //var window = new HomePage();
            //window.ShowDialog();
            //this.Close();

            //show the new form.
            //this.Close(); //only if you want to close the current form.
            try
            {
                if (cmbusertype.Text=="Employee")
                {
                    EmployeeLogs employeeLogs = new EmployeeLogs();
                    employeeLogs.LoginID= Int32.Parse(txtuserid.Text);
                    employeeLogs.Password = txtpassword.Password;
                    con.ConnectionString = connStr;
                    con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;

                    string querry = "Select LoginID,Password from netra.EmployeeLogs where LoginID=@LoginID and Password=@Password ";
                    Command.Parameters.AddWithValue("@LoginID", employeeLogs.LoginID);
                    Command.Parameters.AddWithValue("@Password", employeeLogs.Password);
                    Command.CommandText = querry;

                    SqlDataReader reader = Command.ExecuteReader();
                    //If Database has Record

                    if (reader.HasRows)
                    {

                        HomePage homePage = new HomePage();
                        homePage.Show();
                        this.Close();
                    }
                    //If Database does not have Record

                    else
                    {
                        MessageBox.Show("Not Registered");
                    }

                }

                else if(cmbusertype.Text == "Customer")
                {
                    CustomerLogs customerLogs = new CustomerLogs();

                    customerLogs.LoginID = Int32.Parse(txtuserid.Text);
                    customerLogs.Password = txtpassword.Password;
                    con.ConnectionString = connStr;
                    con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;

                    string querry = "Select LoginID,Password from netra.CustomerLogs where LoginID=@LoginID and Password=@Password ";
                    Command.Parameters.AddWithValue("@LoginID", customerLogs.LoginID);
                    Command.Parameters.AddWithValue("@Password", customerLogs.Password);
                    Command.CommandText = querry;

                    SqlDataReader reader = Command.ExecuteReader();
                    //If Database has Record

                    if (reader.HasRows)
                    {

                        HomePage homePage = new HomePage();
                        homePage.Show();
                        this.Close();
                    }
                    //If Database does not have Record

                    else
                    {
                        MessageBox.Show("Not Registered");
                    }

                }

                else
                {
                    MessageBox.Show("Error Occured While Login...Please Check your details");
                }

                //Users users = new Users();

                //users.LoginID = Int32.Parse(txtuserid.Text);
                //users.Password = txtpassword.Password;
                //con.ConnectionString = connStr;
                //con.Open();
                ////SqlCommand Command = new SqlCommand();
                //Command.Connection = con;

                //string querry = "Select LoginID,Password from [netra].[Users] where LoginID=@LoginID and Password=@Password ";
                //Command.Parameters.AddWithValue("@LoginID", users.LoginID);
                //Command.Parameters.AddWithValue("@Password", users.Password);
                //Command.CommandText = querry;

                //SqlDataReader reader = Command.ExecuteReader();
                //if (reader.HasRows)


                ////if (txtuserid.Text=="asd") /*||(txtuserid.Text==))&&((txtpassword.T))*/
                //{
                //    HomePage homePage = new HomePage();
                //    homePage.Show();
                //    this.Close();
                //}
                //else
                //{
                //    MessageBox.Show("Login Error.Check Your Creditials and Login Once Again");
                //}
            }

            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


        private void btnnewregister_Click(object sender, RoutedEventArgs e)
        {
            NewRegistration newRegistration = new NewRegistration();
            newRegistration.Show();
            this.Close();
        }

        private void AdminLogin_Click(object sender, RoutedEventArgs e)
        {
            AdminPasswordPage adminPage = new AdminPasswordPage();
            adminPage.Show();
        }
    }
}
