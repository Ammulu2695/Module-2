﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for LoginGenerationPage.xaml
    /// </summary>
    public partial class LoginGenerationPage : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();

        public LoginGenerationPage()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (cmbusertype.Text == "Employee")
                {
                    EmployeeLogs employeeLogs = new EmployeeLogs();
                    //Employee employee = new Employee();
                    //employee.EmployeeID = Int32.Parse(txtid.Text);
                    employeeLogs.EmployeeID = Int32.Parse(txtid.Text);
                    employeeLogs.Password = txtpassword.Password;

                    AddEmployeeLogPL(employeeLogs);
                }
                else if(cmbusertype.Text=="Customer")
                {
                    CustomerLogs customerLogs = new CustomerLogs();
                    customerLogs.CustomerID = Int32.Parse(txtid.Text);
                    customerLogs.Password = txtpassword.Password;

                    AddCustomerLogPL(customerLogs);
                }
                else
                {
                    MessageBox.Show("Not Yet Regestered");
                }
            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //Sending values to respective Layers for creating log
        
        private static void AddEmployeeLogPL(EmployeeLogs employeeLogs)
        {

            bool employeelogadded = Logs_BAL.AddEmployeeLogBAL(employeeLogs);

            if (employeelogadded)
            {
                MessageBox.Show(" Login Generated for Employees");
               
                }

                else
                {
                    MessageBox.Show("OOPS!!! Error occured while Login Generation");
                }


            }

        //Sending values to respective Layers for creating log

        private static void AddCustomerLogPL(CustomerLogs customerLogs)
        {

            bool customerlogadded = Logs_BAL.AddCustomerLogBAL(customerLogs);

            if (customerlogadded)
            {
                MessageBox.Show(" Login Generated for Customer");

            }

            else
            {
                MessageBox.Show("OOPS!!! Error occured while Login Generation");
            }


        }




        private void btngetlogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                SqlConnection connection = new SqlConnection();


                connection.ConnectionString = connStr;

                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                if (cmbusertype.Text == "Employee")
                {
                    EmployeeLogs employeeLogs = new EmployeeLogs();
                    employeeLogs.EmployeeID = Int32.Parse(txtid.Text);

                    string querry = "Select LoginID from netra.EmployeeLogs where EmployeeID=@EmployeeID ";
                    // Command.Parameters.AddWithValue("@Password", employeeLogs.Password);
                    Command.Parameters.AddWithValue("@EmployeeID", employeeLogs.EmployeeID);

                    Command.CommandText = querry;

                    SqlDataReader Reader = Command.ExecuteReader();
                    if (Reader.HasRows)
                    {
                        while (Reader.Read())
                        {
                            txtlogin.Text = Reader[0].ToString();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Login Unavailable");
                    }

                }
                else if (cmbusertype.Text == "Customer")
                {
                    CustomerLogs customerLogs = new CustomerLogs();
                    customerLogs.CustomerID = Int32.Parse(txtid.Text);

                    string querry = "Select LoginID from netra.CustomerLogs where CustomerID=@CustomerID ";

                    Command.Parameters.AddWithValue("@CustomerID", customerLogs.CustomerID);

                    Command.CommandText = querry;

                    SqlDataReader Reader = Command.ExecuteReader();
                    //If Database has Record

                    if (Reader.HasRows)
                    {
                        while (Reader.Read())
                        {
                            txtlogin.Text = Reader[0].ToString();
                        }
                    }
                    //If Database does not have Record

                    else
                    {
                        MessageBox.Show("Login Unavailable");
                    }

                }
                else
                {
                    MessageBox.Show("Not Yet Regestered");
                }
            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }


        //Navigate to respective Page
        private void Login_Page_Click(object sender, RoutedEventArgs e)
        {
            MainWindow loginpage = new MainWindow();
            loginpage.Show();
        }
    }
}
