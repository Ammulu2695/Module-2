﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;


namespace Login_Page
{
    /// <summary>
    /// Interaction logic for ManageAllCustomer.xaml
    /// </summary>
    public partial class ManageAllCustomer : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public ManageAllCustomer()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
        //Searching Customer by ID on Click of button

        private void btnsearchemp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer customer = new Customer();
                customer.CustomerID = Int32.Parse(txtmanageallcustid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;
                //string querry = "[netra].[SPsearchEmpById]";
                //Command.Parameters.AddWithValue("@EmployeeID", customer.CustomerID);

                string querry = "[netra].[SPsearchCustById]";
                Command.Parameters.AddWithValue("@CustomerID", customer.CustomerID);

                Command.CommandText = querry;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                SqlDataReader reader = Command.ExecuteReader();
                //If database has value

                if (reader.HasRows)
                {
                    DataTable datatable = new DataTable();
                    datatable.Load(reader);
                    MessageBox.Show("Searched Result Successful");

                }
                //If database does not have value


                else
                {
                    MessageBox.Show("Searched Result Not Successful");
                }
            }

            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
            LoadGrid();
        }

        //Displaying the data

        public void LoadGrid()
        {
            //SqlConnection connection = new SqlConnection();

            try
            {
                //Employee employee = new Employee();
                //employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = con;
                string query = "SELECT * FROM   [netra].[Customer]";
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgmanageallcust.DataContext = Table;


            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        //Searching Employee by ID on Click of button

        private void btndeletecust_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer customer = new Customer();
                customer.CustomerID = Int32.Parse(txtmanageallcustid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;
                string query = "[netra].[SPdeleteCustById]";
                Command.Parameters.AddWithValue("@CustomerID", customer.CustomerID);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfDeleted = Command.ExecuteNonQuery();
                if (NumberOfDeleted == 1)
                {
                    MessageBox.Show("Customer Details Deleted Successfully");
                }
                else
                {
                    MessageBox.Show("Failed to delete Customer");
                }


                //if (reader.HasRows)
                //{
                //    datatable = new DataTable();
                //    datatable.Load(reader);
                //    MessageBox.Show(" Employee Details Deleted");

                //}
                //else
                //{
                //    MessageBox.Show("Employee Details Not Deleted");
                //}
            }
            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Customer Search");
            }
            catch (SqlException Exception)
            {
                MessageBox.Show(Exception.Message, "Customer Search");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            LoadGrid();
        }
        //Sending Values to Respective Layer
        private void btnupdatecust_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomer updateCustomer = new UpdateCustomer();
                updateCustomer.Show();
        }

        private void BacktoAdminDetails_Click(object sender, RoutedEventArgs e)
        {
            AdminDetailsPage adminDetailsPage = new AdminDetailsPage();
            adminDetailsPage.Show();
        }
    }
    
}

