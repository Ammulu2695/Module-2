﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_BAL;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for EmployeeDailyLog.xaml
    /// </summary>
    public partial class EmployeeDailyLog : Window
    {
        public EmployeeDailyLog()
        {
            InitializeComponent();
        }
        //Sending Details to respective layers to add Roster

        private void btnedlsubmit_Click(object sender, RoutedEventArgs e)
        {
            EmployeeRoster employeeRoster = new EmployeeRoster();
            try
            {
                employeeRoster.EmployeeID = Int32.Parse(txtedlempid.Text);
                employeeRoster.FromDate = (dttodaydate.Text).ToString();
                employeeRoster.ToDate = (dttodaydate.Text).ToString();
                employeeRoster.InTime = txtedlintime.Text;
                employeeRoster.OutTime = txtedlouttime.Text;


                AddEmployeeLog(employeeRoster);
            }
            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Employee Roster");
            }
           
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
        }
        private static void AddEmployeeLog(EmployeeRoster employeeRoster)
        {

           
            bool logadded = EmployeeDailyLog_BAL.AddEmployeeLogBAL(employeeRoster);


            //If value return is true
            if (logadded)
            {

                MessageBox.Show(" Employee Log Added");
            }
            //If value return is not true

            else
            {
                MessageBox.Show(" Employee Log Not Added");
            }
        }

        private void BacktoEmployeeDetails_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDetailsPage employeeDetailsPage = new EmployeeDetailsPage();
            employeeDetailsPage.Show();
        }
    }
    
}
