﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for UpdateCustomer.xaml
    /// </summary>
    public partial class UpdateCustomer : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        public UpdateCustomer()
        {
            InitializeComponent();
        }

        //Sending Data to respective Layers for Validations and Updating to database

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            Customer updateCustomer = new Customer();

            try
            {
                updateCustomer.CustomerID = Int32.Parse(txtupdcustid.Text);
                updateCustomer.CustomerName = txtupdcustname.Text;
                updateCustomer.PhoneNumber = txtupdcustphnno.Text;
                updateCustomer.EmailID = txtupdcustemailid.Text;
                updateCustomer.Address = txtupdcustadd.Text;
               

                bool customerupdated = UpdateCustomer_BAL.UpdateCustomerBAL(updateCustomer);

                // If true value is  returned


                if (customerupdated)
                {
                    MessageBox.Show(" Customer Details Updated");
                }

                // If true value is not  returned


                else
                {
                    MessageBox.Show("OOPS!!! Error occured while Updating");
                }

                LoadGrid();
            }

            // If Exception  Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message,"Updating Customer");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }

        }

        //For displaying Data

        public void LoadGrid()
        {
            //SqlConnection connection = new SqlConnection();

            try
            {
                //Employee employee = new Employee();
                //employee.EmployeeID = Int32.Parse(txtmanageallempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = con;
                string query = "SELECT * FROM  [netra].[Employee]";
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                dgUpdatecust.DataContext = Table;


            }

            // If Exception  Occured


            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        private void BacktoAdminDetails_Click(object sender, RoutedEventArgs e)
        {

            AdminDetailsPage adminDetailsPage = new AdminDetailsPage();
            adminDetailsPage.Show();
        }
    }
    
}
