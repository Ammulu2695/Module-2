﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Exception;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for AdminPasswordPage.xaml
    /// </summary>
    public partial class AdminPasswordPage : Window
    {
        public AdminPasswordPage()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            // checking if admin has the below given password
            try
            {


                if (txtpwd.Password == "Pass@admin")
                {
                    AdminDetailsPage adminpage = new AdminDetailsPage();
                    adminpage.Show();
                    this.Close();
                }
                // If Password does not matches
                else
                {
                    MessageBox.Show("You are not Authorized Admin Check for other Login");
                }
            }
            //If Exception Occured
            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Admin Data");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Admin Data");
            }

        }

        private void BackToHomePage_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show(); 

        }
    }
}
