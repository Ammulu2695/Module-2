﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for PrintReportPage.xaml
    /// </summary>
    public partial class PrintReportPage : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public PrintReportPage()
        {
            InitializeComponent();
        }

        //Displaying the Report

        private void BookingReport_Click(object sender, RoutedEventArgs e)
        {
            Loadgrid();
        }

        public void Loadgrid()
        {
            try
            {
                //DataSet dataSet = new DataSet();
                //dataSet = new DataSet("");
                Admin_BAL bookingReportBAL = new Admin_BAL();
                DataTable dt = bookingReportBAL.Display();
                dgSearchReport.ItemsSource = dt.DefaultView;

            }

            //If Exception Occured
            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Report Generation");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
           
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        private void AdminDetailsPage_Click(object sender, RoutedEventArgs e)
        {
            AdminDetailsPage admindetailspage = new AdminDetailsPage();
            admindetailspage.Show();
        }
    }

}
