﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for CheckOnlineBookingPage.xaml
    /// </summary>
    public partial class CheckOnlineBookingPage : Window
    {
        //static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection();

        public CheckOnlineBookingPage()
        {
            InitializeComponent();
        }
        // here is the code

        
       //Displaying Booking Details

            private void LoadGridSearchBooking()
            {
            Booking booking = new Booking();
                try
                {
                con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;
                booking.TaxiID = Int32.Parse(txttaxiid.Text);
                    string query = "SELECT *FROM [netra].[Booking] where TaxiID =@TaxiID";
                   Command.Parameters.AddWithValue("@TaxiID",booking.TaxiID);
                Command.CommandText = query;

                    SqlDataReader Reader = Command.ExecuteReader();
                    DataTable Table = new DataTable();

                //If value return is  true

                if (Reader.HasRows)
                {
                    Table.Load(Reader);

                    dgsearch.DataContext = Table;
                    dgsearch.Visibility = Visibility.Visible;

                    
                }
                //If value return is not true

                else
                {
                    MessageBox.Show("Your  do not have Booking ");
                }

                }
            //If Exception Occured
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            
                finally
                {
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                    con.Close();
                    }

                }
            }

        //private void btnBook_Click(object sender, RoutedEventArgs e)
        //     {
        //         string Hotel_id = txthotid.Text;
        //         Home home = new Home(Hotel_id);
        //         home.Show();
        //         //BookRoom bookRoom = new BookRoom();

        //         this.Close();

        //     }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Booking booking = new Booking();
                booking.TaxiID = Int32.Parse(txttaxiid.Text);
                MessageBox.Show("Your data is Submitted");
            }
            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            LoadGridSearchBooking();
        }

        private void BackToEmployeeDetailsPage_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDetailsPage employeeDetailsPage = new EmployeeDetailsPage();
            employeeDetailsPage.Show();
        }
    }

 }


