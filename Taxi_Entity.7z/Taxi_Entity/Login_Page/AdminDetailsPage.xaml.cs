﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for AdminDetailsPage.xaml
    /// </summary>
    public partial class AdminDetailsPage : Window
    { 
        //Navigations to all the respective Pages

        public AdminDetailsPage()
        {
            InitializeComponent();
        }

        private void btnaddemployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployee addEmployee = new AddEmployee();
            addEmployee.Show();
        }

        private void btnmaintainusers_Click(object sender, RoutedEventArgs e)
        {
            ManageAll manageAll = new ManageAll();
            manageAll.Show();
        }

        private void btnmanagcust_Click(object sender, RoutedEventArgs e)
        {
            ManageAllCustomer managecust = new ManageAllCustomer();
            managecust.Show();
        }

        private void btnchangePassword_Click(object sender, RoutedEventArgs e)
        {
            ChangPassword changPassword = new ChangPassword();
            changPassword.Show();

        }

        private void btncheckfeedback_Click(object sender, RoutedEventArgs e)
        {
            DriverFeedbackPage driverFeedbackPage = new DriverFeedbackPage();
            driverFeedbackPage.Show();
        }

        private void BackTotheHomePage_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();

        }

        private void btnPrintReport_Click(object sender, RoutedEventArgs e)
        {
            PrintReportPage printReportPage = new PrintReportPage();
            printReportPage.Show();
        }
    }
}
