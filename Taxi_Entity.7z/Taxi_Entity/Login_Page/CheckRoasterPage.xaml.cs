﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;


namespace Login_Page
{
    /// <summary>
    /// Interaction logic for CheckRoasterPage.xaml
    /// </summary>
    public partial class CheckRoasterPage : Window
    {
        static string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public CheckRoasterPage()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeRoster employeeRoster  = new EmployeeRoster();

                employeeRoster.EmployeeID = Int32.Parse(txtchkrstrempid.Text);

                con.ConnectionString = connStr;
                con.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = con;

                string query = "[netra].[spgetEmpRoster]";
            

               Command.CommandType = System.Data.CommandType.StoredProcedure;
               
                Command.CommandText = query;

                Command.Parameters.AddWithValue("@EmployeeID", employeeRoster.EmployeeID);
                SqlDataReader Reader = Command.ExecuteReader();
                //If database has records
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        txtfrmdate.Text = Reader[2].ToString();
                        txttodate.Text = Reader[3].ToString();

                    }
                }
                //If database does not have records

                else
                {
                    MessageBox.Show("Roster Unavailable");
                }

            }
            //If Exception Occured

            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }
            
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }

        private void BackToEmployeeDetailsPage_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDetailsPage employeeDetailsPage = new EmployeeDetailsPage();
            employeeDetailsPage.Show();
        }
    }
}
