﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for CalculateFare.xaml
    /// </summary>
    public partial class CalculateFare : Window
    {
        public CalculateFare()
        {
            InitializeComponent();
        }
        // Calculating Fare Based on the time of travel

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

              //  if ((dtstartdt.Text == string.Empty) || (dtenddt.Text == string.Empty)||(txthrs.Text==string.Empty)) { MessageBox.Show("The field cannot be blank"); }

                Booking booking = new Booking();
                booking.TripStartDate = DateTime.Parse(dtstartdt.Text);
                booking.TripEndDate = DateTime.Parse(dtenddt.Text);

                double cost;
                if (dtstartdt.Text == dtenddt.Text)
                {
                    int i = Int32.Parse(txthrs.Text);

                    if ((i <= 24)&&(i>0))
                    {
                        cost = 50 * i;
                        MessageBox.Show("Is Your Fare", cost.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Hours more than 24  Go for different dates");
                    }
                }
                double hours = ((DateTime.UtcNow - booking.TripStartDate).TotalHours - (DateTime.UtcNow - booking.TripEndDate).TotalHours);


                //if (hours <= 1)
                //{
                //    cost = 50;
                //    MessageBox.Show("Is Your Fare", cost.ToString());
                //}
                //else 
                if (hours > 1)
                {
                    cost = 50 * hours;
                    MessageBox.Show("Is Your Fare", cost.ToString());
                }
            }

            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Calculate Fare");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }


        }

        private void BackToCustomerDetailsPage_Click(object sender, RoutedEventArgs e)
        {
            CustomerDetailsPage customerDetails = new CustomerDetailsPage();
            customerDetails.Show();
        }
    }
    
}
