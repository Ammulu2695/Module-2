﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for EmployeeDetailsPage.xaml
    /// </summary>
    public partial class EmployeeDetailsPage : Window
    {
        public EmployeeDetailsPage()
        {
            InitializeComponent();
        }

        //private void btnaddemployee_Click(object sender, RoutedEventArgs e)
        //{
          
        //}

        private void btnchkroster_Click(object sender, RoutedEventArgs e)
        {

            CheckRoasterPage checkRoasterPage = new CheckRoasterPage();
            checkRoasterPage.Show();

        }

        private void btnchkdailylog_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDailyLog employeeDailyLog = new EmployeeDailyLog();
            employeeDailyLog.Show();
        }

        private void btnchkonlibook_Click(object sender, RoutedEventArgs e)
        {
            CheckOnlineBookingPage checkOnlineBookingPage = new CheckOnlineBookingPage();
            checkOnlineBookingPage.Show();
        }

        private void BackToHomePage_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
        }
    }
}
