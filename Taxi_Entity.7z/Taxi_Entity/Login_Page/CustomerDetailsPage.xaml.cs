﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using Taxi_BAL;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for CustomerDetailsPage.xaml
    /// </summary>
    public partial class CustomerDetailsPage : Window
    {
        //Navigates to Respective Pages
        public CustomerDetailsPage()
        {
            InitializeComponent();
        }

        private void btnmakebooking_Click(object sender, RoutedEventArgs e)
        {
            BookingPage bookingpage = new BookingPage();
            bookingpage.Show();
            this.Close();
        }

        private void Btncalfare_Click(object sender, RoutedEventArgs e)
        {
            CalculateFare calculateFare = new CalculateFare();
            calculateFare.Show();
        }

        private void btncheckbookstst_Click(object sender, RoutedEventArgs e)
        {
            BookingStatusPage bookingStatusPage = new BookingStatusPage();
            bookingStatusPage.Show();
        }

        private void btndriverhistory_Click(object sender, RoutedEventArgs e)
        {
            DriverFeedbackPage driverFeedbackPage = new DriverFeedbackPage();
            driverFeedbackPage.Show();
        }

        private void BacktoHomePage_Click(object sender, RoutedEventArgs e)
        {
            HomePage homePage = new HomePage();
            homePage.Show();
        }
    }
}
