﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_BAL;
using Taxi_DAL;
using System.Data.SqlClient;
using System.Configuration;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
      // SqlCommand Command;

        public AddEmployee()
        {
            InitializeComponent();
        }
        // Sending Data to respective layers

        private void btnaddemp_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                Employee newemployee = new Employee();

                newemployee.EmployeeID = Int32.Parse(txtempid.Text);
                newemployee.EmployeeName = txtempname.Text;
                newemployee.TaxiID = Int32.Parse(txtTaxiID.Text);
                newemployee.PhoneNumber = txtphnno.Text;
                newemployee.EmailID = txtemailadd.Text;
                newemployee.Address = txtadd.Text;
                newemployee.DirvingLicenseNumber = txtdrivglisence.Text;


                AddEmployeePL(newemployee);
            }
            //If Exception Occured
            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Adding Employee");
            }
            catch (Exception)
            {
                MessageBox.Show("Something went wrong ......Either ID already exists or some fields are left blank or invalid entries");
            }


        }

        private static void AddEmployeePL(Employee newemployee)
        {
            
            
                bool employeeadded = Admin_BAL.AddEmployeeBAL(newemployee);
           
            //If returned value is true
                if (employeeadded)
                {
                  MessageBox.Show(" Entry Confirmed to Employees");
                LoginGenerationPage loginGeneration = new LoginGenerationPage();
                loginGeneration.Show();
            }
            //If returned value is not true

            else
            {
                    MessageBox.Show("OOPS!!! Error occured while adding");
                }
            
           
        }
    }
}
