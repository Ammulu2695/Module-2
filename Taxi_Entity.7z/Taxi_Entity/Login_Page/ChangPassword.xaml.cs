﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Taxi_Entity;
using Taxi_DAL;
using System.Configuration;
using System.Data.SqlClient;
using Taxi_Exception;

namespace Login_Page
{
    /// <summary>
    /// Interaction logic for ChangPassword.xaml
    /// </summary>
    public partial class ChangPassword : Window
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);

        public ChangPassword()
        {
            InitializeComponent();
        }
        //Submitting Old Password

        private void btnoldpass_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbusertype.Text == "Employee")
                {
                    EmployeeLogs employeeLogs = new EmployeeLogs();
                    employeeLogs.LoginID = Int32.Parse(txtpculoginid.Text);
                    employeeLogs.Password = txtoldpwd.Password;

                    //    Users users = new Users();
                    //users.LoginID = Int32.Parse(txtpculoginid.Text);
                    //users.Password = txtoldpwd.Password;

                    con.ConnectionString = connStr;
                    con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;

                    string querry = "Select LoginID,Password from netra.EmployeeLogs where LoginID=@LoginID and Password=@Password ";
                    Command.Parameters.AddWithValue("@LoginID", employeeLogs.LoginID);
                    Command.Parameters.AddWithValue("@Password", employeeLogs.Password);
                    Command.CommandText = querry;

                    SqlDataReader reader = Command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        MessageBox.Show(" Valid Employee Password can be Changed");
                    }

                    else
                    {
                        MessageBox.Show("No Record Found");
                    }
                }
                else if (cmbusertype.Text == "Customer")
                {
                    CustomerLogs customerLogs = new CustomerLogs();

                    customerLogs.LoginID = Int32.Parse(txtpculoginid.Text);
                    customerLogs.Password = txtoldpwd.Password;

                    con.ConnectionString = connStr;
                    con.Open();
                    SqlCommand Command = new SqlCommand();
                    Command.Connection = con;

                    string querry = "Select LoginID,Password from  netra.CustomerLogs where LoginID=@LoginID and Password=@Password ";
                    Command.Parameters.AddWithValue("@LoginID", customerLogs.LoginID);
                    Command.Parameters.AddWithValue("@Password", customerLogs.Password);
                    Command.CommandText = querry;

                    SqlDataReader reader = Command.ExecuteReader();
                 
                    //If database has record
                    if (reader.HasRows)
                    {
                        MessageBox.Show(" Valid Customer Password can be Changed");
                    }
                    //If database does not have record

                    else
                    {
                        MessageBox.Show("No Record Found");
                    }
                }
                //If entered data does not matches the value of combobox
                else
                {
                    MessageBox.Show("Not Valid User...Please Check your details");
                }

            }

            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Change Password");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Change Password");
            }


        }
        //Getting new  Password

        private void btnnewpass_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (cmbusertype.Text == "Employee")
                {
                    EmployeeLogs employeeLogs = new EmployeeLogs();

                    // Users users = new Users();
                    if (txtoldpwd.Password == txtnewpwd.Password)
                    {
                        MessageBox.Show("You Cannot have New Password and Old Password Same");
                    }

                    else
                    {
                        //con.ConnectionString = connStr;
                        //con.Open();
                        SqlCommand Command = new SqlCommand();
                        Command.Connection = con;
                        employeeLogs.LoginID = Int32.Parse(txtpculoginid.Text);
                        employeeLogs.Password = txtnewpwd.Password;

                        string querry = " update netra.EmployeeLogs set Password=@Password   where LoginID =@LoginID ";
                        Command.CommandText = querry;
                        Command.Parameters.AddWithValue("@LoginID", employeeLogs.LoginID);
                        Command.Parameters.AddWithValue("@Password", employeeLogs.Password);
                        Command.CommandText = querry;

                        int NumberOfRowsAdded = Command.ExecuteNonQuery();

                        //If Row gets Added

                        if (NumberOfRowsAdded == 1)
                        {
                            MessageBox.Show("Password Changed Successfully");
                        }

                        //If Row does not Adds

                        else
                        {
                            MessageBox.Show("Password Not Changed ");
                        }

                    }
                }
                else if (cmbusertype.Text == "Customer")
                {
                    CustomerLogs customerLogs = new CustomerLogs();

                    if (txtoldpwd.Password == txtnewpwd.Password)
                    {
                        MessageBox.Show("You Cannot have New Password and Old Password Same");
                    }

                    else
                    {
                        //con.ConnectionString = connStr;
                        //con.Open();
                        SqlCommand Command = new SqlCommand();
                        Command.Connection = con;
                        customerLogs.LoginID = Int32.Parse(txtpculoginid.Text);
                        customerLogs.Password = txtnewpwd.Password;

                        string querry = " update netra.CustomerLogs set Password=@Password   where LoginID =@LoginID ";
                        Command.CommandText = querry;
                        Command.Parameters.AddWithValue("@LoginID", customerLogs.LoginID);
                        Command.Parameters.AddWithValue("@Password", customerLogs.Password);
                        Command.CommandText = querry;

                        int NumberOfRowsAdded = Command.ExecuteNonQuery();
                        //If Row gets Added

                        if (NumberOfRowsAdded == 1)
                        {
                            MessageBox.Show("Password Changed Successfully");
                        }
                        //If Row does not Adds

                        else
                        {
                            MessageBox.Show("Password Not Changed ");
                        }

                    }
                }
                //If entered data does not matches the value of combobox

                else
                {
                      MessageBox.Show("Not Valid User ");
                    }


            }    
            //If Exception Occured

            catch (TaxiNotFoundException ex)
            {
                MessageBox.Show(ex.Message, "Change Password");
            }
            catch (Exception)
            {
                MessageBox.Show("All  fields are required");
            }

        }
        //Navigating to another Page

        private void BackToAdminDetailsPage_Click(object sender, RoutedEventArgs e)
        {
            AdminDetailsPage adminDetailsPage = new AdminDetailsPage();
            adminDetailsPage.Show();
        }
    }
}
