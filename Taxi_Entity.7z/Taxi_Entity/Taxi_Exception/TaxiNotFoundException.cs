﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Exception
{
    //This is Exception Class dealing with Exceptions

    
    public class TaxiNotFoundException: Exception
    {
            public TaxiNotFoundException() { }

            public TaxiNotFoundException(string message) : base(message) { }

            public TaxiNotFoundException(string message, Exception inner) : base(message, inner) { }



        
    }
}
