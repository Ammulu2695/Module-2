﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;


namespace Taxi_DAL
{
    public class UpdateCustomer_DAL
    {

        //Updating Customer is done here

        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
       

        public bool UpdateCustomerDAL(Customer updateCustomer)
        {
            bool customerupdated = false;
            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for updating Customer


                string query = "[netra].[SPupdateCustById]";

                Command.Parameters.AddWithValue("@CustomerID", updateCustomer.CustomerID);
                Command.Parameters.AddWithValue("@CustomerName", updateCustomer.CustomerName);
                Command.Parameters.AddWithValue("@PhoneNumber", updateCustomer.PhoneNumber);
                Command.Parameters.AddWithValue("@EmailID", updateCustomer.EmailID);
                Command.Parameters.AddWithValue("@Address", updateCustomer.Address);
               
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();

                //If rows gets added then return to presentation layer

                if (NumberOfRowsAdded == 1)
                    customerupdated = true;
            }

               //Else throw Exception   

            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }

            catch(SqlException ex1 )
            {
                throw ex1;
            }

            return customerupdated;

        }
    }
}