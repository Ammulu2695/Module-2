﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_DAL;
using Taxi_Exception;
using Taxi_Entity;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace Taxi_DAL
{
    public class SearchVehicle_DAL
    {  
        //Searching Taxi is done here

        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(connStr);

        public DataTable Display()
        {
            DataTable datatable = null;
            try
            {
               SqlCommand command = new SqlCommand();

                //Stored Procedure for searching Taxi

                command.CommandText = "[netra].[SPSearchTaxi]";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                //If database has  the searched record then return to presentation layer

                if (reader.HasRows)
                {
                    datatable = new DataTable();
                    datatable.Load(reader);
                }
            }

            //Else throw Exception   

            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch(SystemException ex2)
            {
                throw ex2;
            }
            finally
            {
                if(connection.State== ConnectionState.Open)
                {
                    connection.Close();
                }
            }

            return datatable;
        }
    }
}
