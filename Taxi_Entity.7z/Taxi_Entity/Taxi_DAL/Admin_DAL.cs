﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Taxi_DAL
{
    public class Admin_DAL
    {
        //This is DAL for functions of  Admin which  Adds a new Employee and Prints Report


        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();


        public bool AddEmployeeDAL(Employee newemployee)
        {
            bool employeeadded = false;
            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for Adding a Employee


                string query = "[netra].[SPAddEmployee]";

                Command.Parameters.AddWithValue("@EmployeeID", newemployee.EmployeeID);
                Command.Parameters.AddWithValue("@EmployeeName", newemployee.EmployeeName);
                Command.Parameters.AddWithValue("@TaxiID", newemployee.TaxiID);
                Command.Parameters.AddWithValue("@PhoneNumber", newemployee.PhoneNumber);
                Command.Parameters.AddWithValue("@EmailID", newemployee.EmailID);
                Command.Parameters.AddWithValue("@Address", newemployee.Address);
                Command.Parameters.AddWithValue("@DirvingLicenseNumber", newemployee.DirvingLicenseNumber);

               

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();

                //If rows gets added then return to presentation layer


                if (NumberOfRowsAdded == 1)
                    employeeadded = true;
            }

            //Else throw Exception   

            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return employeeadded;

        }

      public DataTable DisplayDal()
        {
            DataTable dt = null;
            try
            {
                // Printing  Report is done here

                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                // Stored Procedure for Printing Report 

                string query = "[netra].[PrintReports]";

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
               
                SqlDataReader dr = Command.ExecuteReader();

                //If the record is present in database then return to presentation layer


                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            //Else throw Exception   


            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if(connection.State==ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return dt;
        }
}
}
