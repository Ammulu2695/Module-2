﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Exception;
using Taxi_Entity;
using System.Data;

namespace Taxi_DAL
{
  public  class EmployeeDailyLog_DAL
    {
        //Adding roster for Employee is done here


        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();

        public bool AddEmployeeLogDAL(EmployeeRoster employeeRoster)
        {
            bool logadded = false;

            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for adding Employee Roster


                string query = "[netra].[spgetEmployeeLog]";
                Command.Parameters.AddWithValue("@RosterID", SqlDbType.Int);
                Command.Parameters["@RosterID"].Direction = ParameterDirection.Output;

                Command.Parameters.AddWithValue("@EmployeeID", employeeRoster.EmployeeID);
                Command.Parameters.AddWithValue("@FromDate", employeeRoster.FromDate);
                Command.Parameters.AddWithValue("@ToDate", employeeRoster.ToDate);
                Command.Parameters.AddWithValue("@InTime", employeeRoster.InTime);
                Command.Parameters.AddWithValue("@OutTime", employeeRoster.OutTime);
                
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                //If rows gets added then return to presentation layer


                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    logadded = true;
            }

            //Else throw Exception   


            catch (TaxiNotFoundException)
            {
                throw;
            }
            return logadded;
        }
    }
}
