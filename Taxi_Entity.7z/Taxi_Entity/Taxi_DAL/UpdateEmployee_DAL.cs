﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;
using Taxi_DAL;
using System.Data;

namespace Taxi_DAL
{
  public  class UpdateEmployee_DAL
    {
        //Updating Employee is done here

        
             static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        Employee employee = new Employee();

        public bool UpdateEmployeeDAL(Employee updateEmployee)
        {
            bool employeeupdated = false;
            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for updating Employee

                string query = "[netra].[SPUpdateEmpById]";

                Command.Parameters.AddWithValue("@EmployeeID", updateEmployee.EmployeeID);
                Command.Parameters.AddWithValue("@EmployeeName", updateEmployee.EmployeeName);
                Command.Parameters.AddWithValue("@TaxiID", updateEmployee.TaxiID);
                Command.Parameters.AddWithValue("@PhoneNumber", updateEmployee.PhoneNumber);
                Command.Parameters.AddWithValue("@EmailID", updateEmployee.EmailID);
                Command.Parameters.AddWithValue("@Address", updateEmployee.Address);
                Command.Parameters.AddWithValue("@DirvingLicenseNumber", updateEmployee.DirvingLicenseNumber);



                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                
                //If rows gets added then return to presentation layer

                    if (NumberOfRowsAdded == 1)
                    employeeupdated = true;
            }

            //Else throw Exception   

            catch (TaxiNotFoundException ex)
            {
                throw ex;
            }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            return employeeupdated;

        }
       
    }
}
