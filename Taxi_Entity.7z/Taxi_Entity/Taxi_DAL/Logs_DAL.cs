﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Taxi_Entity;
using Taxi_Exception;

namespace Taxi_DAL
{
    public class Logs_DAL
    {
        //Adding login for Customer as well as Employee is done here

        static string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();


        public bool AddEmployeeLogsDAL(EmployeeLogs employeeLogs)
        {
            bool employeeadded = false;
            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for adding Employee Log


                string query = "[netra].[SPAddEmployeeLogin]";

                Command.Parameters.AddWithValue("@Password", employeeLogs.Password);
                Command.Parameters.AddWithValue("@EmployeeID", employeeLogs.EmployeeID);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();

                //If rows gets added then return to presentation layer

                if (NumberOfRowsAdded == 1)
                    employeeadded = true;
            }

            //Else throw Exception   

            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return employeeadded;

        }

        public bool AddCustomerLogsDAL(CustomerLogs customerLogs)
        {
            bool customerlogadded = false;
            try
            {
                connection.ConnectionString = connStr;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;

                //Stored Procedure for adding Customer Log

                string query = "[netra].[SPAddNewCustomerLogin]";

                Command.Parameters.AddWithValue("@Password", customerLogs.Password);
                Command.Parameters.AddWithValue("@CustomerID", customerLogs.CustomerID);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;

                //If rows gets added then return to presentation layer

                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    customerlogadded = true;
            }

               //Else throw Exception   

            catch (TaxiNotFoundException)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return customerlogadded;

        }


    }
    }
