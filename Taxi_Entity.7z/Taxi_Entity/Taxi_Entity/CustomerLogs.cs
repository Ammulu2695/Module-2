﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
   public class CustomerLogs
    {
        //All the fields required for creating Customer Log

        public int LoginID { get; set; }

        public string Password { get; set; }

        public int CustomerID { get; set; }

    }
}
