﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
   public class Customer
    {
        //All the fields required for  Customer are declared here

        public int CustomerID { get; set; }

        public string CustomerName { get; set; }

        public string PhoneNumber { get; set; }

        public string EmailID { get; set; }

        public string Address { get; set; }
    }
}
