﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
    public class Employee
    {
        //All the fields required for  Employee 


        public int EmployeeID { get; set; }

        public string EmployeeName { get; set; }

        public int TaxiID { get; set; }

        public string PhoneNumber { get; set; }

        public string EmailID { get; set; }

        public string Address { get; set; }

        public string DirvingLicenseNumber { get; set; }


    }
}
