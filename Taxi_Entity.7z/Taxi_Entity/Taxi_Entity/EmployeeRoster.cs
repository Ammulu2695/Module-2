﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
  public  class EmployeeRoster
    {

        //All the fields required for   Employee Roster


        public int EmployeeID { get; set; }

        public int RosterID { get; set; }

        public string FromDate { get; set; }

        public string ToDate { get; set; }

        public string InTime { get; set; }

        public string OutTime { get; set; }

        


    }
}
