﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
     public class Booking
     {

      //All the fields required for booking are declared here

        public int BookingID { get; set; }

        public int CustomerID { get; set; }

        public int TaxiID { get; set; }

        public DateTime TripStartDate { get; set; }

        public DateTime TripEndDate { get; set; }

        public string StartTime { get; set; }

        public string EndTime { get; set; }

        public string SourceAddress { get; set; }

        public string DestinationAddress { get; set; }

       
    }
}
