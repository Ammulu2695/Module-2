﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
   public class EmployeeLogs
    {
        //All the fields required for creating  Employee Log


        public int LoginID { get; set; }

        public string Password { get; set; }

        public int EmployeeID { get; set; }
    }
}
