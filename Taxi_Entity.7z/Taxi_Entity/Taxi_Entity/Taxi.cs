﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Taxi_Entity
{
   public class Taxi
    {

        //All the fields required for Feedbacks are declared

        public int TaxiID { get; set; }

        public string TaxiModel { get; set; }

        public string Color { get; set; }

        public int RegistrationNumber { get; set; }

        public string TaxiType { get; set; }
    }
}
