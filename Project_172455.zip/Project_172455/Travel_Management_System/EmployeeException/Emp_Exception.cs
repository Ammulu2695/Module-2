﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeException
{

    public class Emp_Exception : Exception
    {
        public Emp_Exception() { }
        public Emp_Exception(string message) : base(message) { }
     
    }
}
