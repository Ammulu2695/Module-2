﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeTravelRequestEntity;
using EmployeeException;
using System.Data;

namespace TravelRequestDAL
{
   

        //public  bool ExpenseRequest_DAL(TravelRequest tr)
        //{
        //    bool expenseAdded = false;
        //    Connection.ConnectionString = ConnectionString;

        //    Connection.Open();

        //    //Command=new SqlCommand("") 

        //    return expenseAdded;
        //}

        

        //public TravelRequest SearchTravelRequest_DAL(int MR_number)
        //{
        //    TravelRequest pendingrequest = new TravelRequest();
        //    Connection.ConnectionString = ConnectionString;

        //    Connection.Open();

        //    try
        //    {
        //        SqlCommand Command;
        //        Command = new SqlCommand("Select * from Project_172455_TravelDetails where MR_Number=@MR_Number", Connection);
        //        Command.Parameters.AddWithValue("@MR_Number", MR_number);
        //        //Command.CommandType = CommandType.StoredProcedure;

        //        SqlDataReader reader = Command.ExecuteReader();

        //        if (reader.HasRows)
        //        {

        //            while (reader.Read())
        //            {
        //                pendingrequest.Employee_ID = int.Parse(reader[1].ToString());
        //                pendingrequest.MR_Number = int.Parse(reader[0].ToString());
        //                pendingrequest.Apply_Date = Convert.ToDateTime(reader[2]);
        //                pendingrequest.Reason_For_Travel = reader[3].ToString();
        //                pendingrequest.Travel_Date = Convert.ToDateTime(reader[4].ToString());
        //                pendingrequest.Travel_Mode = reader[5].ToString();
        //                pendingrequest.From_city = reader[6].ToString();
        //                pendingrequest.To_City = reader[7].ToString();
        //                pendingrequest.Travel_Duration = Int32.Parse(reader[8].ToString());

        //            }

        //        }

        //    }
        //    catch (Emp_Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return pendingrequest;
        //}
    }
    

