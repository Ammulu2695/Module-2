﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;


namespace MainPage
{
    /// <summary>
    /// Interaction logic for EmployeeLogin.xaml
    /// </summary>
    public partial class EmployeeLogin : Page
    {
        Emp_BAL emp = new Emp_BAL();
       public string uname,pwd;
        public EmployeeLogin()
        {
            InitializeComponent();
        }

        

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Emp_Entity employee = new Emp_Entity();
                employee = null;
                uname = txtusername.Text;
                pwd = txtpassword.Password.ToString();

                if(String.IsNullOrEmpty(uname) || String.IsNullOrEmpty(pwd))
                {
                    MessageBox.Show("You must Enter credentials to login.");
                }
                else
                {
                    employee = emp.Emp_Login_BAL(uname, pwd);
                }

                if (employee != null)
                {
                    MessageBox.Show("Logged in");
                    EmployeePage page = new EmployeePage(employee);
                    this.NavigationService.Navigate(page);
                }
                else
                {
                    MessageBox.Show("Invlid Credentials");
                }
            }
            catch (Emp_Exception)
            {
                MessageBox.Show("Cannot Login");
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot Login");
            }
        }

    }
}


