﻿using EmployeeEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for EmployeePage.xaml
    /// </summary>
    public partial class EmployeePage : Page
    {
        string User;
        Emp_Entity empnew= new Emp_Entity();

        public EmployeePage()
        {
            InitializeComponent();
        }

        public EmployeePage(Emp_Entity val) : this()
        {
            empnew= val;
            User = val.FirstName;
            this.Loaded += new RoutedEventHandler(Page_Loaded);   
        }
       
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            welcomeUser.Text ="Welcome "+ User;
            
        }

        private void EmpUpdateDetails_Click(object sender, RoutedEventArgs e)
        {
            EmployeeDetailsUpdateByEmployee emp = new EmployeeDetailsUpdateByEmployee(empnew);
            this.NavigationService.Navigate(emp);
        }

        private void EmpExpenseRequest_Click(object sender, RoutedEventArgs e)
        {
            ExpenseRequestGeneration expense = new ExpenseRequestGeneration(empnew);
            this.NavigationService.Navigate(expense);
        }

        private void EmpTravelRequest_Click(object sender, RoutedEventArgs e)
        {
            TravelRequestPage travel = new TravelRequestPage(empnew);
            this.NavigationService.Navigate(travel);
        }

        private void EmpTravelRequestUpdate_Click(object sender, RoutedEventArgs e)
        {
            TravelRequestUpdatePage treqUpdate = new TravelRequestUpdatePage(empnew);
            this.NavigationService.Navigate(treqUpdate);
        }

        private void EmpExpenseRequestUpdate_Click(object sender, RoutedEventArgs e)
        {
            ExpenseRequestUpdatePage expReqUpdate = new ExpenseRequestUpdatePage(empnew);
            this.NavigationService.Navigate(expReqUpdate);
        }
    }
}
