﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeBAL;
using EmployeeTravelRequestEntity;

using EmployeeException;
using EmployeeEntity;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for TravelRequest.xaml
    /// </summary>
    public partial class TravelRequestPage : Page
    {
        int empid;
        public TravelRequestPage()
        {
            InitializeComponent();
        }
        public void Clearall()
        {
            txtFromCity.Text = string.Empty;
            txtToCity.Text = string.Empty;
            txtReason.Text = string.Empty;
            txtTravelDuration.Text = string.Empty;
        }
        public TravelRequestPage(Emp_Entity val) : this()
        {
          
            empid = val.Employee_ID;
           
            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }

        private void btnGenRequest_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtApplyDate.Text) || String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtFromCity.Text) || String.IsNullOrEmpty(txtMR_Number.Text) || String.IsNullOrEmpty(txtReason.Text) || String.IsNullOrEmpty(txtToCity.Text) || String.IsNullOrEmpty(dptraveldate.Text) || String.IsNullOrEmpty(txtTravelDuration.Text) || String.IsNullOrEmpty(cbTravelMode.Text))
            {
                MessageBox.Show("Fields Cannot be Empty");
            }

            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtMR_Number.Text))
            {
                for (int i = 0; i < txtMR_Number.Text.Length; i++)
                {
                    if (!char.IsNumber(txtMR_Number.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in MR Number.");
                        i = txtMR_Number.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtFromCity.Text))
            {
                for (int i = 0; i < txtFromCity.Text.Length; i++)
                {
                    if (!char.IsLetter(txtFromCity.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in from City.");
                        i = txtFromCity.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtToCity.Text))
            {
                for (int i = 0; i < txtToCity.Text.Length; i++)
                {
                    if (!char.IsLetter(txtToCity.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in To city.");
                        i = txtToCity.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtTravelDuration.Text))
            {
                for (int i = 0; i < txtTravelDuration.Text.Length; i++)
                {
                    if (!char.IsNumber(txtTravelDuration.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Travel Duration.");
                        i = txtTravelDuration.Text.Length + 1;
                    }
                }
            }
            else if (int.Parse(txtTravelDuration.Text) <= 0)
            {
                MessageBox.Show("Travel Duration Cannot be 0 or less.");
            }
            else if (int.Parse(txtMR_Number.Text) <= 0)
            {
                MessageBox.Show("MR Number Cannot be 0 or less.");
            }
            else if (int.Parse(txtEmpID.Text) <= 0)
            {
                MessageBox.Show("Employee ID cannot be 0 or less.");
            }
            else
            {
                TravelRequest tr = new TravelRequest();
                try
                {
                    tr.MR_Number = int.Parse(txtMR_Number.Text);
                    tr.Employee_ID = empid;
                    tr.Apply_Date = Convert.ToDateTime(txtApplyDate.Text);
                    tr.Reason_For_Travel = txtReason.Text;
                    tr.Travel_Date = Convert.ToDateTime(dptraveldate.ToString());
                    tr.Travel_Mode = cbTravelMode.Text;
                    tr.From_city = txtFromCity.Text;
                    tr.To_City = txtToCity.Text;
                    tr.Travel_Duration = int.Parse(txtTravelDuration.Text);
                    tr.Request_Status = "Pending";


                    bool requestAdded = TReq_BAL.TravelRequest_BAL(tr);

                    if (requestAdded)
                    {
                        MessageBox.Show("Added Sccessfully");

                    }
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message + "Travel Request");
                }
                catch (Exception)
                {
                    MessageBox.Show("All Fields are Mandatory and type specific.");
                }
                finally
                {
                    Clearall();
                }
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Random random = new Random();
            int x = random.Next(100000);
            txtEmpID.Text = empid.ToString();
            txtApplyDate.Text = DateTime.Now.ToString();
            txtMR_Number.Text = x.ToString();
        }
    }
}
