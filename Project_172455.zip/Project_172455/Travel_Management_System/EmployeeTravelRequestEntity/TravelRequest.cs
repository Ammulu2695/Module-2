﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeTravelRequestEntity
{
    public class TravelRequest
    {
        public int MR_Number { get; set; }
        public int Employee_ID { get; set; }
        public DateTime Apply_Date { get; set; }
        public string Reason_For_Travel { get; set; }
        public DateTime Travel_Date { get; set; }
        public string Travel_Mode { get; set; }
        public string From_city { get; set; }
        public string To_City { get; set; }
        public int Travel_Duration { get; set; }
        public string Request_Status { get; set; }
    }
}
