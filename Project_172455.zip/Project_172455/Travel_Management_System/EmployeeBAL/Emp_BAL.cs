﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeEntity;
using EmployeeException;
using EmployeeDAL;
using EmployeeTravelRequestEntity;
using ExpenseRequestEntity;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace EmployeeBAL
{
    public class Emp_BAL
    {
        Emp_DAL emp = new Emp_DAL();

        public DataSet LoadGrid_Employees_BAL()
        {
            Emp_DAL emp = new Emp_DAL();
            DataSet dataset = new DataSet();
            dataset = emp.LoadGrid_Employees_DAL();
            return dataset;
        }

        private bool ValidateEmployee(Emp_Entity newEmployee)
        {
            bool isValidEmployee = true;
            StringBuilder EmpRegError = new StringBuilder();


            if (!(Regex.IsMatch(newEmployee.Employee_ID.ToString(), "^[1-9][0-9]{3}$")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Employee ID must be 4 digits and must not start with 0." + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.FirstName, "[A-Z][a-z]{3,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (!(Regex.IsMatch(newEmployee.LastName, "[A-Z][a-z]{3,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Last Name must have only characters starting with uppercase " + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.Password, "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{4,}$")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Password Should Have Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character: " + Environment.NewLine);
            }
            

            if (!(Regex.IsMatch(newEmployee.Location, "[A-Z][a-z]{2,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Location Name Cannot be greater than 15 Characters" + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.Reimburse_Account_No.ToString(), "^[1-9][0-9]{6}$")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Reimbursement Account Number Should be less Than or Equal to 7 Digits Only" + Environment.NewLine);
            }


            if (String.IsNullOrEmpty(newEmployee.FirstName))
            {
                EmpRegError.Append("First Name Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newEmployee.LastName))
            {
                EmpRegError.Append("Last Name Required" + Environment.NewLine);
            }


            if (String.IsNullOrEmpty(newEmployee.Reimburse_Account_No.ToString()))
            {
                EmpRegError.Append("Account Number Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(newEmployee.Password))
            {
                EmpRegError.Append("Password Cannot be Blank" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(newEmployee.Location))
            {
                EmpRegError.Append("Location Required" + Environment.NewLine);
            }

            if (isValidEmployee == false)
                throw new Emp_Exception(EmpRegError.ToString());
            return isValidEmployee;

        }


        private bool ValidateUpdateEmployee(Emp_Entity newEmployee)
        {
            bool isValidEmployee = true;
            StringBuilder EmpRegError = new StringBuilder();


            if (!(Regex.IsMatch(newEmployee.Employee_ID.ToString(), "^[1-9][0-9]{3}$")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Employee ID must be 4 digits and must not start with 0." + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.FirstName, "[A-Z][a-z]{3,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("First Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (!(Regex.IsMatch(newEmployee.LastName, "[A-Z][a-z]{3,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Last Name must have only characters starting with uppercase " + Environment.NewLine);
            }
            


            if (!(Regex.IsMatch(newEmployee.Location, "[A-Z][a-z]{2,}")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Location Name Cannot be greater than 15 Characters" + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newEmployee.Reimburse_Account_No.ToString(), "^[1-9][0-9]{6}$")))
            {
                isValidEmployee = false;
                EmpRegError.Append("Reimbursement Account Number Should be less Than or Equal to 7 Digits Only" + Environment.NewLine);
            }


            if (String.IsNullOrEmpty(newEmployee.FirstName))
            {
                EmpRegError.Append("First Name Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newEmployee.LastName))
            {
                EmpRegError.Append("Last Name Required" + Environment.NewLine);
            }


            if (String.IsNullOrEmpty(newEmployee.Reimburse_Account_No.ToString()))
            {
                EmpRegError.Append("Account Number Required" + Environment.NewLine);
            }
            
            if (String.IsNullOrEmpty(newEmployee.Location))
            {
                EmpRegError.Append("Location Required" + Environment.NewLine);
            }

            if (isValidEmployee == false)
                throw new Emp_Exception(EmpRegError.ToString());
            return isValidEmployee;

        }


        public bool Emp_RegisterBAL(Emp_Entity Emp)
        {
            bool registered = false;
            try
            {
                if (ValidateEmployee(Emp))
                {
                    if (emp.Emp_Register(Emp))
                    {
                        registered = true;
                    }
                    
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
           
            return registered;
        }

        public bool Emp_UpdatebyEmpBAL(Emp_Entity empup)
        {
            bool updated = false;
            try
            {
                if (ValidateEmployee(empup))
                {
                    updated = emp.Emp_UpdatebyEmpDAL(empup);    
                }

                else
                    updated = false;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return updated;
        }

        public bool Emp_UpdateBAL(Emp_Entity newemp)
        {
            bool updated = false;
            try
            {
                if (ValidateUpdateEmployee(newemp))
                {
                    emp.Emp_UpdateDAL(newemp);
                    updated = true;
                }

                else
                    updated = false;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Emp_Exception ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return updated;
        }

        public Emp_Entity Emp_Login_BAL(string uname, string pwd)
        {
            Emp_Entity employee = new Emp_Entity();
            try
            {
                 employee = emp.Emp_Login_DAL(uname, pwd);
            
            }
            catch(Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
               
            
            return employee;
        }

        //public Emp_Entity Emp_BAL_SearchEmp(int empsearch)
        //{
        //    Emp_Entity searchedemp = new Emp_Entity();
        //    Emp_DAL emp_DAL = new Emp_DAL();
        //    try
        //    {
        //        searchedemp = emp_DAL.Emp_DAL_SearchEmp(empsearch);
        //    }
        //    catch (Emp_Exception)
        //    {
        //        throw;
        //    }
        //    catch (SqlException)
        //    {
        //        throw;
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }     
        //    return searchedemp;
        //}
    }




    public class ExpenseBAL
    {

       public int ExpenseRequestCount_BAL()
        {
            int count;
            try
            {
                ExpenseDAL expensecount = new ExpenseDAL();
                count = expensecount.ExpenseRequestCount_DAL();
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
           
            return count;
        }

        private static bool ValidateExpenseRequest(ExpenseRequest newrequest)
        {
            bool isValidRequest = true;
            StringBuilder EmpRegError = new StringBuilder();


            if (!(Regex.IsMatch(newrequest.Employee_ID.ToString(), "^[1-9][0-9]{3,5}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Employee ID must be 4 digits and must not start with 0." + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newrequest.MR_Number.ToString(), "[1-9]{3,5}")))
            {
                isValidRequest = false;
                EmpRegError.Append("MR Number must be an Integer" + Environment.NewLine);
            }

            if (!(Regex.IsMatch(newrequest.ExpenseReport_ID.ToString(), "[0-9]{3,5}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Expense Report Id must be an Integer " + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newrequest.Amount_Paid.ToString(), "[0-9]{2,4}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Amount Paid Must be in DIgits only and less than 10000: " + Environment.NewLine);
            }

            if ((newrequest.Expense_Date) > DateTime.Now)
            {
                isValidRequest = false;
                EmpRegError.Append("You can only apply for previous Expenses made. " + Environment.NewLine);
            }



            if (String.IsNullOrEmpty(newrequest.Employee_ID.ToString()))
            {
                EmpRegError.Append("Employee Id Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newrequest.MR_Number.ToString()))
            {
                EmpRegError.Append("MR Number Must Required" + Environment.NewLine);
            }



            if (isValidRequest == false)
                throw new Emp_Exception(EmpRegError.ToString());
            return isValidRequest;

        }

        public DataSet LoadGrid_PendingExpenseDetails_BAL()
        {
            ExpenseDAL emp = new ExpenseDAL();
            DataSet dataset = new DataSet();
            dataset = emp.LoadGrid_PendingExpenseDetails_DAL();
            return dataset;
        }


        public DataSet ExpenseRequestUpdate_LoadGrid_BAL(int empid)
        {
            ExpenseDAL treq = new ExpenseDAL();
            DataSet dataset = new DataSet();
            dataset = treq.ExpenseRequestUpdate_LoadGrid_DAL(empid);
            return dataset;
        }

        public bool ExpenseRequestGen_BAL(ExpenseRequest er)
        {
            bool ExpenseReqGen=false;
            try
            {
                if (ValidateExpenseRequest(er))
                {
                    ExpenseDAL expense = new ExpenseDAL();
                    ExpenseReqGen = expense.ExpenseRequestGen_DAL(er);
                }
            }
            catch(Emp_Exception)
            {
                throw;
            }
            catch(SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
           
            return ExpenseReqGen;
        }

        public ExpenseRequest SearchExpenseRequest_BAL(int MR_number)
        {
            ExpenseRequest requestUpdate = new ExpenseRequest();

            try
            {
                ExpenseDAL request = new ExpenseDAL();
                requestUpdate = request.SearchExpenseRequest_DAL(MR_number);
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return requestUpdate;
        }

        public bool ExpenseStatus_BAL(int MR_number, string statusUpdate)
        {
            bool statusUpdated = false;
            try
            {
                ExpenseDAL req = new ExpenseDAL();
                 statusUpdated = req.ExpenseStatus_DAL(MR_number, statusUpdate);
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return statusUpdated;
        }

        public int AutoIncrExpenseId_BAL()
        {
            int expenseId;
            try
            {
                ExpenseDAL expense = new ExpenseDAL();
                expenseId = expense.AutoIncrExpenseId_DAL();
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return expenseId;
        }

        public static bool UpdateTravelRequest_BAL(ExpenseRequest tr)
        {
            ExpenseDAL req_DAL = new ExpenseDAL();
            bool reqAdded = false;
            try
            {
                if (ValidateExpenseRequest(tr))
                {
                    reqAdded = req_DAL.UpdateExpenseRequest_DAL(tr);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return reqAdded;
        }

    }





    public class TReq_BAL
    {

        public int TravelRequestCount_BAL()
        {
            int TravelReqcount;
            try
            {
                TReq_DAL travelcount = new TReq_DAL();
                TravelReqcount = travelcount.TravelRequestCount_DAL();
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return TravelReqcount;
        }



            private static bool ValidateTravelRequest(TravelRequest newrequest)
        {
            bool isValidRequest = true;
            StringBuilder EmpRegError = new StringBuilder();


            if (!(Regex.IsMatch(newrequest.Employee_ID.ToString(), "^[1-9][0-9]{3}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Employee ID must be 4 digits and must not start with 0." + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newrequest.MR_Number.ToString(), "[1-9]{3,}")))
            {
                isValidRequest = false;
                EmpRegError.Append("MR Number must be an Integer" + Environment.NewLine);
            }

            if (!(Regex.IsMatch(newrequest.Reason_For_Travel, "[A-Z][a-z]{3,}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Reason must have only characters starting with uppercase " + Environment.NewLine);
            }
            if (!(Regex.IsMatch(newrequest.Travel_Duration.ToString(), "[0-9]{1}")))
            {
                isValidRequest = false;
                EmpRegError.Append("Travel Days must be less than 10: " + Environment.NewLine);
            }

            if ((newrequest.Travel_Date) < DateTime.Now)
            {
                isValidRequest = false;
                EmpRegError.Append("You can only apply for Upcoming travel dates. " + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newrequest.Employee_ID.ToString()))
            {
                EmpRegError.Append("Employee Id Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(newrequest.MR_Number.ToString()))
            {
                EmpRegError.Append("MR Number Must Required" + Environment.NewLine);
            }


            if (String.IsNullOrEmpty(newrequest.Reason_For_Travel))
            {
                EmpRegError.Append("Reason Must Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(newrequest.Travel_Duration.ToString()))
            {
                EmpRegError.Append("How Many Days You want to travel" + Environment.NewLine);
            }
           

            if (isValidRequest == false)
                throw new Emp_Exception(EmpRegError.ToString());
            return isValidRequest;

        }

        public DataSet LoadGrid_PendingTravelDetails_BAL()
        {
            TReq_DAL treq = new TReq_DAL();
            DataSet dataset = new DataSet();
            dataset = treq.LoadGrid_PendingTravelRequests_DAL();
            return dataset;
        }

        public DataSet TravelRequestUpdate_LoadGrid_BAL(int empid)
        {
            TReq_DAL treq = new TReq_DAL();
            DataSet dataset = new DataSet();
            dataset = treq.TravelRequestUpdate_LoadGrid_DAL(empid);
            return dataset;
        }

        public static bool TravelRequest_BAL(TravelRequest tr)
        {
            TReq_DAL req_DAL = new TReq_DAL();
            bool reqAdded = false;
            try
            {
                if (ValidateTravelRequest(tr))
                {
                    reqAdded = req_DAL.TravelRequest_DAL(tr);
                }
            }
            catch (SqlException )
            {
                throw;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (Exception )
            {
                throw;
            }
            return reqAdded;
        }

        public static bool UpdateTravelRequest_BAL(TravelRequest tr)
        {
            TReq_DAL req_DAL = new TReq_DAL();
            bool reqAdded = false;
            try
            {
                if (ValidateTravelRequest(tr))
                {
                    reqAdded = req_DAL.UpdateTravelRequest_DAL(tr);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Emp_Exception)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return reqAdded;
        }

        public bool RequestStatus_BAL(int MR_number, string statusUpdate)
        {
          
            TReq_DAL req = new TReq_DAL();
            bool statusUpdated = req.ReuestStatus_DAL(MR_number, statusUpdate);

            return statusUpdated;
        }

        //public TravelRequest SearchTravelRequest_BAL(int MR_number)
        //{
        //    TravelRequest requestUpdate = new TravelRequest();
        //    TReq_DAL request = new TReq_DAL();
        //    requestUpdate = request.SearchTravelRequest_DAL(MR_number);

        //    return requestUpdate;
        //    //if (requestUpdate != null)
        //    //{

        //    //}
        //}
      
    }
}
