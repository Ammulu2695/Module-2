﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console12._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*******copy file operation********");
            Console.WriteLine("enter source filename:");
            string sourceFileName = Console.ReadLine();
            Console.WriteLine("enter destination filename:");
            string destFileName = Console.ReadLine();
            try
            {
                File.Copy(sourceFileName, destFileName);
                Console.WriteLine("copied successfully");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }
            Console.ReadLine();
        }
    }
}
