﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_3
{
    [Serializable]
    class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public double MobileNumber { get; set; }
        public Student()
        {

        }
        public Student(int RollNo,string Name,double MobileNumber)
        {
            this.RollNo = RollNo;
            this.Name = Name;
            this.MobileNumber = MobileNumber;
        }
        public override string ToString()
        {
            return $"{RollNo},{Name},{MobileNumber}";             //$"RollNo {RollNo}, Name {FullName}, FeesPaid {FeesPaid}, DOB {DOB}";            
        }
    }
}
