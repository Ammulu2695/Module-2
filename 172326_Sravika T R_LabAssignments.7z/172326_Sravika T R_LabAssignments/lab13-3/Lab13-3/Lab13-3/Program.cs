﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab13_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "Students.sser";

            ArrayList students = new ArrayList
            {
                new Student { RollNo = 1, Name = "Sravika",MobileNumber=912345670 },
                new Student { RollNo = 2, Name = "Susmitha",MobileNumber=1234567890 },
                new Student { RollNo = 3,Name = "Sharmeela", MobileNumber=2345678910 }
            };

            SerializeStudents(filePath, students);

            ArrayList c_students = DeserializeStudents(filePath);
            foreach (var item in c_students)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }

        private static void SerializeStudents(string filePath, ArrayList students)
        {
            FileStream fileStream = new FileStream(filePath, FileMode.Create);
            //BinaryFormatter binaryFormatter = new BinaryFormatter();
            //binaryFormatter.Serialize(fileStream, students);
            SoapFormatter soapFormatter = new SoapFormatter();
            soapFormatter.Serialize(fileStream, students);
            fileStream.Close();
        }
        private static ArrayList DeserializeStudents(string filePath)
        {
            FileStream fileStream = new FileStream(filePath, FileMode.Open);
            //BinaryFormatter binaryFormatter = new BinaryFormatter();
            //List<Student> students = (List<Student>) binaryFormatter.Deserialize(fileStream);
            SoapFormatter soapFormatter = new SoapFormatter();
            ArrayList students = (ArrayList)soapFormatter.Deserialize(fileStream);
            fileStream.Close();
            return students;
        }
    }
    }

