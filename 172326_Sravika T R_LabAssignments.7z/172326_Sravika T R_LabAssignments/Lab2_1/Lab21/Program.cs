﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab21
{
    class Program
    {

        public struct variable
        {
            /*public int num;*/

            public static int Square(int num)
            {
                return num * num;
            }
            public static int Cube(int num)
            {
                return num * num * num;
            }
        }

        static void Main(string[] args)
        {
            variable v1;
            int num;
            Console.WriteLine("Enter the number");
            num = Convert.ToInt32(Console.ReadLine());
            int op;
            int sq, cb;
            Console.WriteLine("Enter the Operation");
            op = Convert.ToInt32(Console.ReadLine());
            switch(op)
            {
                case 1:
                   sq=variable.Square(num);
                    Console.WriteLine($"Square of a {num} is : {sq}");
                    break;
                case 2:
                    cb=variable.Cube(num);
                    Console.WriteLine($"Cube of a {num} is : {cb}");
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
            Console.ReadKey();


        }
    }
}
