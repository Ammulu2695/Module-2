﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console12._2
{
    class Program
    {
        static void Main(string[] args)
        {
            try { 
            Console.WriteLine("*******copy file operation********");
            Console.WriteLine("enter source filename:");
            string sourceFileName = Console.ReadLine();
            string path = $@"C:\Users\sravtr\Desktop\Lab Assignment\assign12-1\{sourceFileName}.txt";
            FileStream s = File.Create(path);
            string text = "A class is the one thing you have to fod od oifmn  ";
            s.Close();
            System.IO.File.WriteAllText($@"C:\Users\sravtr\Desktop\Lab Assignment\{sourceFileName}.txt", text);

            Console.WriteLine("===============Reading the text from file===============================");
            string tex;
            var fileStream = new FileStream($@"C:\Users\sravtr\Desktop\Lab Assignment\{sourceFileName}.txt", FileMode.Open, FileAccess.Read);
            using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
            {
                    tex = streamReader.ReadToEnd();
            }
                Console.WriteLine(tex);


            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }
            Console.ReadLine();
        }
    }
}
