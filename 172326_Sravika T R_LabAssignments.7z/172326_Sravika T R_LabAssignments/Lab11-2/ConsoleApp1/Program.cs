﻿


using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

namespace _11._2_Console

{

    class Program

    {

        static void Main(string[] args)

        {

            //Instantiate

            FileDownloader fd = new

            FileDownloader("http://www.microsoft.com/vstudio/expressv10.zip",

            "d:\\setups");

            //Register Event Handler

            fd.DownLoadComplete += new DownloadCompeteHandler(fd_DownLoadComplete);

            //Start the task...

            fd.DownLoadResource();

            Console.ReadKey();

        }

        static void fd_DownLoadComplete(int perc)

        {

            Console.SetCursorPosition(10, 10);

            Console.Write("Downloading {0} Percent Complete", perc);

        }

    }

    public delegate void DownloadCompeteHandler(int perc);

    public class FileDownloader

    {

        protected string resourceUrl;

        protected string resourceSavePath;

        public event DownloadCompeteHandler DownLoadComplete;

        public FileDownloader(string url, string savepath)

        {

            this.resourceUrl = url;

            this.resourceSavePath = savepath;

        }

        public void DownLoadResource()

        {

            //This is just download simulation place holder code

            for (int i = 1; i <= 4; i++)

            {

                //Dummy loop to add a delay

                for (int j = 1; i <= 10000; i++) ;

                OnDownLoadComplete(i * 25);

            }

        }

        public void OnDownLoadComplete(int perc)

        {

            if (DownLoadComplete == null)

                DownLoadComplete(perc);

        }

    }

}
