﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_2
{
    delegate int MyDeleagte(int n1, int n2);
    class Progarm
    {
        static void PerformArithmeticOperation(int num1, int num2, MyDeleagte arOperation)
        {
            Console.WriteLine(arOperation(num1, num2));
            //Console.WriteLine("Enter a numbers");
            //int n1;
            //n1 = Convert.ToInt32(Console.ReadLine());
            //int n2;
            //n2 = Convert.ToInt32(Console.ReadLine());
        }
            public static int Add(int n1, int n2)
            {
                return n1 + n2;
            }
        public static int Sub(int n1, int n2)
        {
            return n1 - n2;
        }
        public static int Mul(int n1, int n2)
        {
            return n1 * n2;
        }
        public static int Div(int n1, int n2)
        {
            return n1 / n2;
        }
        public static int Max(int n1, int n2)
        {
            if (n1 > n2)
            {
                return n1;
            }
            else
            {
                return n2;
            }
        }



         static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Enter the numbers:");
            Console.WriteLine("Enter the number1");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number 2");
            n2 = Convert.ToInt32(Console.ReadLine());
            MyDeleagte del1 = new MyDeleagte(Add);
            PerformArithmeticOperation(n1, n2, del1);
            del1 += new MyDeleagte(Sub);
            PerformArithmeticOperation(n1, n2, del1);
            del1 += new MyDeleagte(Mul);
            PerformArithmeticOperation(n1, n2, del1);
            del1 += new MyDeleagte(Div);
            PerformArithmeticOperation(n1, n2, del1);
            del1 += new MyDeleagte(Max);
            PerformArithmeticOperation(n1, n2, del1);
            //AODelegate d1 = new AODelegate(ArthemeticOperations.Add);
            //Console.WriteLine(d1(n1, n2));
            //d1 += new AODelegate(ArthemeticOperations.Sub);
            //Console.WriteLine(d1(n1, n2));
            //d1 += new AODelegate(ArthemeticOperations.Mul);
            //Console.WriteLine(d1(n1, n2));
            //d1 += new AODelegate(ArthemeticOperations.Div);
            //Console.WriteLine(d1(n1, n2));
            //d1 += new AODelegate(ArthemeticOperations.Max);
            //Console.WriteLine(d1(n1, n2));
            Console.ReadKey();


        }
    }
}