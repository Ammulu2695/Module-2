﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab41
{
    class Program
    {
        static void Main(string[] args)
        {
            int op;
            ContractEmployee con = new ContractEmployee();
            PermanentEmployee per = new PermanentEmployee();
            Console.WriteLine("Enter the employee type to be entered:\n 1.ContractEmployee 2.PermanentEmployee");
            op = Convert.ToInt32(Console.ReadLine());
            switch(op)
            {
                case 1:
                    Console.WriteLine("Enter the Employee ID");
                    int a = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the Employee Name");
                    string b=Console.ReadLine();
                    Console.WriteLine("Enter the Employee Salary");
                    double c = double.Parse(Console.ReadLine());

                    double j = con.GetSalary(c);
                    con.GetSalary(j);
                    Console.WriteLine(j);
                    Console.ReadKey();
                    break;
                case 2:
                    Console.WriteLine("Enter the Employee ID");
                    int d = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter the Employee Name");
                    string e = Console.ReadLine();
                    Console.WriteLine("Enter the Employee Salary");
                    double f = double.Parse(Console.ReadLine());
                    double g = per.GetSalary(f);
                    per.GetSalary(g);
                    Console.WriteLine(g);
                    Console.ReadKey();
                    break;
                default:
                    break;
            }
            Console.ReadKey();
            //Employee e = new Employee();
            //Console.WriteLine("Enter the Employee Details");
            //Console.WriteLine("Enter the Employee ID");
            //e.EmpId = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Enter the Employee Name");
            //e.EmpName =Console.ReadLine();
            //Console.WriteLine("Enter the Employee Address");
            //e.Address = Console.ReadLine();
            //Console.WriteLine("Enter the Employee City");
            //e.City = Console.ReadLine();
            //Console.WriteLine("Enter the Employee Department");
            //e.Department = Console.ReadLine();
            //Console.WriteLine("Enter the Employee Salary");
            //e.EmpId = Convert.ToInt32(Console.ReadLine());
        }
    }
}
