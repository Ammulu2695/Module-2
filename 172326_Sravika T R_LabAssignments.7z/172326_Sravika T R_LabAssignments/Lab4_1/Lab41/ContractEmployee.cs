﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab41
{
    class ContractEmployee : Employee
    {
        public double Perks=2000.5,salary;
      
        public override double GetSalary(double salary)
        {
            return salary + Perks;

        }
    }
}
