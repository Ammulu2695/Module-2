﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidLab
{
    class Program
    {
        static void Main(string[] args)
        {
            ContractEmployee a = new ContractEmployee();
            String s=a.GetProjectDetails(1);
            Console.WriteLine("contract empoyee:"+s);
            try
            {
                a.GetEmployeeDetails(1);
            }
            catch
            {

                Console.WriteLine("Details not found ");
                Console.WriteLine("Liskov substitution principle");
            }
            AddOperation z = new AddOperation();
            getOperation w = new getOperation();
            z.AddEmployeeDetails();
            try
            {
                w.ShowEmployeeDetails(1);
            }
            catch
            {

                Console.WriteLine("Details not found ");
                Console.WriteLine("integration segregation  principle");
            }
            
            //List<Employee1> employeeList = new List<Employee1>();
            //employeeList.Add(a);
            ////employeeList.Add(new PermanentEmployee());
            //foreach (Employee1 e in employeeList)
            //{
            //    e.GetEmployeeDetails(1245);
            //}
            //Console.ReadKey();
        }
    }
}
