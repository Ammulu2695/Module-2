﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14
{
    class Program
    {
        static void Main(string[] args)
        {
            SchoolDemo[] sd = new SchoolDemo[2];
            Console.WriteLine("Enter the Student Details");
            for (int i = 0; i < 2; i++)
            {
                sd[i] = new SchoolDemo();
                Console.WriteLine("Enter RollNumber");
                sd[i].RollNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter StudentName");
                sd[i].StudentName = Console.ReadLine();
                Console.WriteLine("Enter Age");
                sd[i].Age = Convert.ToByte(Console.ReadLine());
                Console.WriteLine("Enter Gender");
                sd[i].Gender = Convert.ToChar(Console.ReadLine());
                Console.WriteLine("Enter Date Of Birth");
                sd[i].Dob = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Address");
                sd[i].Address = Console.ReadLine();
                Console.WriteLine("Enter Percentage");
                sd[i].Percentage = Convert.ToDouble(Console.ReadLine());
            }
                for (int i = 0; i < sd.GetLength(0); i++)
                {
                    Console.WriteLine("{0},{1},{2},{3},{4},{5},{6}",sd[i].RollNumber, sd[i].StudentName, sd[i].Age, sd[i].Gender, sd[i].Address, sd[i].Dob, sd[i].Percentage);
                }
            
            Console.ReadKey();
        }
    }
}
