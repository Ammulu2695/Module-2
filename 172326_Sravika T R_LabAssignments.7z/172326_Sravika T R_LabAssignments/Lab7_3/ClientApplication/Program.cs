﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientApplication
{
    class Program
    {
        static List<ClientApplication.Employee> employee = new List<ClientApplication.Employee>();

        static void Main(string[] args)

        {

            PrintMenu();

            Console.ReadLine();

        }

        static void PrintMenu()

        {

            string choice1;

            do

            {

                Console.WriteLine("select ur choice:");

                Console.WriteLine("1. Add Employee\n2. Display Employee\n3. Edit Employee\n4. Show all Employee");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)

                {

                    case 1:

                        AddEmployee();

                        break;

                    case 2:

                        DisplayEmployee();

                        break;

                    case 3:

                        EditEmployee();

                        break;

                    case 4:

                        ListAllEmployee();

                        break;

                }

                Console.WriteLine("Do you want to continue(y/n)?");

                choice1 = Console.ReadLine();

            } while (choice1 == "y");

            Console.ReadLine();

        }

        static void AddEmployee()

        {

            ClientApplication.Employee con = new ClientApplication.Employee();

            Console.WriteLine("enter Employee id:");

            con.EmployeeId= int.Parse(Console.ReadLine());

            Console.WriteLine("enter Employee name: ");

            con.EmployeeName = Console.ReadLine();

            Console.WriteLine("enter salary: ");

            con.Salary= double.Parse(Console.ReadLine());

            employee.Add(con);
            Console.WriteLine("Employee Details added successfully");

        }

        static void DisplayEmployee()

        {

            List<ClientApplication.Employee> cont = employee;

           // Console.WriteLine("no name cell");

            foreach (ClientApplication.Employee c in cont)

            {

                Console.WriteLine(c.EmployeeId + " " + c.EmployeeName + " " + c.Salary);

            }
            Console.WriteLine("Employee Details displayed successfully");
        }

        static void EditEmployee()

        {

            List<ClientApplication.Employee> contt = employee;

            int employeeID;

            Console.WriteLine("enter contact id:");

            employeeID = int.Parse(Console.ReadLine());

            for (int i = 0; i < contt.Count; i++)

            {

                ClientApplication.Employee cont = employee[i];

                if (employeeID == cont.EmployeeId)

                {

                    Console.WriteLine("enter name:");

                    cont.EmployeeName = Console.ReadLine();

                    Console.WriteLine("enter salary:");

                    cont.Salary=double.Parse( Console.ReadLine());

                }

            }
            Console.WriteLine("Employee Details edited successfully");

        }

        static void ListAllEmployee()

        {

            List<ClientApplication.Employee> cont = employee;

            //Console.WriteLine("no name cell");

            foreach (ClientApplication.Employee c in cont)

            {

                Console.WriteLine(c.EmployeeId + " " + c.EmployeeName+ " " + c.Salary);

            }
            Console.WriteLine("Employee Details showed successfully ");

        }
        
    }
}
