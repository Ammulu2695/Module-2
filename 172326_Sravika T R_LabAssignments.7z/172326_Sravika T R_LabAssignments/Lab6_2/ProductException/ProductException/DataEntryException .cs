﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductException
{

    [Serializable]
    public class DataEntryException : Exception
    {
        public DataEntryException() { }
        public DataEntryException(string message) : base(message) { }
        public DataEntryException(string message, Exception inner) : base(message, inner) { }
        protected DataEntryException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
