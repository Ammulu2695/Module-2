﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductException
{
    class ProductMock
    {
        private int ProId;
        public int ProductId1
        {
            get { return ProId; }
            set { ProId = value; }
        }

        private String proName;
        public string productName1
        {
            get { return proName; }
            set { proName = value; }
        }


        private double price;
        public double price1
        {
            get { return price; }
            set { price = value; }
        }


        public ProductMock()
        {

        }
        public ProductMock(int ProductId, string productName, double price)
        {
            ProId = ProductId;
            proName = productName;
            this.price = price;

        }





    }
}

