﻿create procedure Balancecredit(
@Account_No bigint,
@Balance int

)
as
begin
update ProjectAccountMaster_172311 set Balance=@Balance where Account_No=@Account_No
end