﻿CREATE PROCEDURE Searchthroughdate
	(
	@DateofTransaction date,
	@Account_No bigint
	)
AS
begin
	select *  from ProjectTransactions_172311 where DateofTransaction=@DateofTransaction and  Account_No=@Account_No
end