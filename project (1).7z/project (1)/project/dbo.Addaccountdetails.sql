﻿CREATE Procedure Addaccountdetails(

@Account_Type varchar(50),
@Balance int,
@Opening_Date date,
@Name varchar(50),
@Email varchar(50),
@HouseAddress nvarchar(max),
@Pancard_no varchar(50),
@AccountaccessMode varchar(50),
@username varchar(50),
@PassWord varchar(50)
)
As
Begin
insert into ProjectAccountMaster_172311(
Account_Type,Balance,Opening_Date,Name,Email,HouseAddress,Pancard_no,AccountaccessMode,username,PassWord
)
values (
@Account_Type,@Balance,@Opening_Date,@Name,@Email,@HouseAddress,@Pancard_no,@AccountaccessMode,@username,@PassWord)
end