﻿create procedure searchbalancess
(
@Account_No bigint
)
as
Begin
SELECT * from ProjectAccountMaster_172311 where Account_No=@Account_No
end
