﻿create procedure addbilldetails
(

@phoneno bigint,
@mobilenetwork varchar(50),
@rechargeammount int
)
as
begin
insert into Projectbillpaymentss_172311( phoneno,
mobilenetwork ,
rechargeammount )
values (@phoneno,@mobilenetwork,@rechargeammount)
end
