﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingData
{
    public class LoanDal
    {
        static string conStr = string.Empty;
        SqlConnection connection = null;
        SqlCommand command = null;
        double p,res,r,n;
        
        
        static LoanDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public LoanDal()
        {
            connection = new SqlConnection(conStr);
        }
        public void addLoandetails(Loans addloan)
        {
            try
            {
                calculateemi(addloan);
                command = new SqlCommand();
                command.CommandText = "addloandetails";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@AccountID",addloan.AccountID);
                command.Parameters.AddWithValue("@TypeofLoan",addloan.TypeofLoan);
                command.Parameters.AddWithValue("@loanammount",addloan.loanammount);
                command.Parameters.AddWithValue("@DurationofLoan",addloan.DurationofLoan);
                command.Parameters.AddWithValue("@EMI",addloan.EMI);
                command.Parameters.AddWithValue("@Applicationstatus",addloan.Applicationstatus);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (SqlException Exception)
            {

                throw Exception;
            }
            catch (DetailesnotfoundException Exception)
            {
                throw Exception;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }
        public void calculateemi(Loans loans)
        {
            p = loans.loanammount;
            n = loans.DurationofLoan;
            if (loans.TypeofLoan == "Personal loan")
            {
                r = 0.100;
                double a=1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
            else if(loans.TypeofLoan == "car loan")
            {
                r = 0.800;
                double a = 1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
            else if(loans.TypeofLoan == "Bike loan")
            {
                r = 0.810;
                double a = 1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
            else if(loans.TypeofLoan == "Home loan")
            {
                r = 0.650;
                double a = 1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
            else if (loans.TypeofLoan == "agriculture loan")
            {
                r = 0.550;
                double a = 1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
            else if (loans.TypeofLoan == "student loan")
            {
                r = 0.680;
                double a = 1;
                for (int i = 0; i < n; i++)
                {
                    a = a * (1 + r);
                }
                res = ((p * r * (a)) / (a - 1));
            }
           loans.EMI = res;
        }

        public Loans detailsloans(string accountno)
        {
            Loans loans = new Loans();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("display5", connection);                
                command.CommandType = CommandType.StoredProcedure;
               command.Parameters.AddWithValue("@AccountID", accountno);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        loans.LoanID = int.Parse(reader[0].ToString());
                        loans.AccountID = int.Parse(reader[1].ToString());
                        loans.TypeofLoan = reader[2].ToString();
                        loans.loanammount   = int.Parse(reader[3].ToString());
                        loans.DurationofLoan = int.Parse(reader[4].ToString());
                        loans.EMI = int.Parse(reader[5].ToString());
                        loans.Applicationstatus = reader[6].ToString();
                        
                    }
                }

            }

            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return loans;
        }

    }
}
