﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingData
{
    public class onlinebankdata
    {
        static string conStr = string.Empty;
        SqlConnection connection = null;
        SqlCommand command = null;
        static onlinebankdata()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public onlinebankdata()
        {
            connection = new SqlConnection(conStr);
        }
        public void AddAccountdetailsDal (Account_master addnew)
        {
            try
            {
                command = new SqlCommand();
                command.CommandText = "Addaccountdetails";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Account_Type",addnew.Account_Type);
                command.Parameters.AddWithValue("@Balance",addnew.Balance);
                command.Parameters.AddWithValue("@Opening_Date",addnew.OpeningDate);
                command.Parameters.AddWithValue("@Name",addnew.Name);
                command.Parameters.AddWithValue("@Email",addnew.Email);
                command.Parameters.AddWithValue("@HouseAddress",addnew.HouseAddress);
                command.Parameters.AddWithValue("@Pancard_no",addnew.Pancard_No);
                command.Parameters.AddWithValue("@AccountaccessMode",addnew.AccountaccessMode);
                command.Parameters.AddWithValue("@username",addnew.username);
                command.Parameters.AddWithValue("@PassWord",addnew.PassWord);
                connection.Open();
                int noOfRowsAffected = command.ExecuteNonQuery();

            }
            catch  (SqlException)
            {
                throw;
            }
            catch (DetailesnotfoundException)
            {

                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public void updatepassworddal(Account_master addpass)
        {
            try
            {
                command = new SqlCommand();
                command.CommandText = "updatepassword";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@username", addpass.username);
                command.Parameters.AddWithValue("@PassWord", addpass.PassWord);
                connection.Open();
                int noOfRowsAffected = command.ExecuteNonQuery();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (DetailesnotfoundException)
            {

                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        //public void transferfundcreditdal(Account_master addamount)
        //{
        //    try
        //    {
        //        command = new SqlCommand();
        //        command.CommandText = "Balancecredit";
                
        //        command.Connection = connection;
        //        command.CommandType = CommandType.StoredProcedure;
        //        command.Parameters.AddWithValue("@Account_No", addamount.Account_No);
        //        command.Parameters.AddWithValue("@Balance", addamount.Balance);
                
        //        connection.Open();
        //        int noOfRowsAffected = command.ExecuteNonQuery();

        //    }
        //    catch (SqlException)
        //    {
        //        throw;
        //    }
        //    catch (DetailesnotfoundException)
        //    {

        //        throw;
        //    }
        //    finally
        //    {
        //        if (connection.State == ConnectionState.Open)
        //        {
        //            connection.Close();
        //        }
        //    }
        //}

        public void updatecredit(Account_master addamount)
        {
            try
            {
                command = new SqlCommand();
                command.CommandText = "updateBalancecredit";                
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Account_No", addamount.Account_No);
                command.Parameters.AddWithValue("@Balance", addamount.Balance);                
                connection.Open();
                int noOfRowsAffected = command.ExecuteNonQuery();

            }
            catch (SqlException)
            {
                throw;
            }
            catch (DetailesnotfoundException)
            {

                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public void transferfunddebitdal(Account_master addamounts)
        {
            try
            {
                command = new SqlCommand();
                command.CommandText = "Balancedebit";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Account_No", addamounts.Account_No);
                command.Parameters.AddWithValue("@Balance", addamounts.Balance);
                connection.Open();
                int noOfRowsAffected = command.ExecuteNonQuery();

            }
            catch (SqlException)
            {
                throw;
            }
            catch (DetailesnotfoundException)
            {

                throw;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public void updatebalancedal(Account_master updatebalance)
        {

            try
            {
                command = new SqlCommand();
                command.CommandText = "updatebalance";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Account_No", updatebalance.Account_No);
                command.Parameters.AddWithValue("@Balance", updatebalance.Balance);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (SqlException)
            {

                throw;
            }
            catch (DetailesnotfoundException)
            {
                throw;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }
        public Account_master detailsdisp(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("disp2", connection);               
                command.CommandType = CommandType.StoredProcedure;                
                command.Parameters.AddWithValue("@username", uname);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        master.Account_No =int.Parse(reader[0].ToString());
                        master.Balance = int.Parse(reader[1].ToString());
                        master.Name = reader[2].ToString();
                    }
                }
                
            }
            
            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return master;
        }

        public Account_master displaytranction(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("disp1", connection);               
                command.CommandType = CommandType.StoredProcedure;                
                command.Parameters.AddWithValue("@username", uname);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        master.Account_No = int.Parse(reader[0].ToString());
                        master.Balance = int.Parse(reader[1].ToString());
                        
                    }
                }

            }

            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return master;
        }

        public Account_master displayloans(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("display4", connection);              
                command.CommandType = CommandType.StoredProcedure;             
                command.Parameters.AddWithValue("@username", uname);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        master.Account_No = int.Parse(reader[0].ToString());                       
                    }
                }

            }

            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return master;
        }
        public Account_master detailsuserdal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("disp", connection);            
                command.CommandType = CommandType.StoredProcedure;                
                command.Parameters.AddWithValue("@username", uname);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        master.Name = reader[0].ToString();
                        master.Balance = int.Parse(reader[1].ToString());
                        master.Account_No = int.Parse(reader[2].ToString());
                        
                    }
                }

            }

            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return master;
        }
        public Account_master detailsaccountdetalsdal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                connection.ConnectionString = conStr;
                connection.Open();                
                command = new SqlCommand("display3", connection);                
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@username", uname);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        master.Account_No = int.Parse(reader[0].ToString());
                    }
                }

            }

            catch (SqlException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
            return master;
        }
    }
}
