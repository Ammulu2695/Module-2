﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingData
{
    public class TransactionDal
    {
        static string conStr = string.Empty;
        SqlConnection connection = null;
        SqlCommand command = null;
        static TransactionDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public TransactionDal()
        {
            connection = new SqlConnection(conStr);
        }
        public void addTransactiondetails(Transactionsentity addtrans)
        {
            try
            {
                command = new SqlCommand();
                command.CommandText = "AddTransactiondetails";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
               // command.Parameters.AddWithValue("@Transaction_ID",addtrans.Transaction_ID);
                command.Parameters.AddWithValue("@DateofTransaction",addtrans.DateofTransaction);
                command.Parameters.AddWithValue("@TypeofTransaction",addtrans.TypeofTransaction);
                command.Parameters.AddWithValue("@Account_No",addtrans.Account_No);
                command.Parameters.AddWithValue("@amount",addtrans.amount);
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (SqlException)
            {

                throw;
            }
            catch(DetailesnotfoundException)
            {
                throw;

            }
            finally
            {
                if (connection.State==ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }


        //public void claculation(Transactionsentity addcal)
        //{

        //}
        public DataSet searchthroughdate(Transactionsentity adddate)
        {
            try
            {
                
                command = new SqlCommand();
                command.CommandText = "Searchthroughdate";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@DateofTransaction",adddate.DateofTransaction);
                command.Parameters.AddWithValue("@Account_No", adddate.Account_No);
                connection.Open();
                SqlCommandBuilder builder = new SqlCommandBuilder();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                builder.DataAdapter = sqlDataAdapter;
                DataSet dataset = new DataSet();
                sqlDataAdapter.Fill(dataset);
                return dataset;                
            }
            catch (SqlException)
            {

                throw;
            }
            catch (DetailesnotfoundException)
            {
                throw;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }


        public DataSet top5transaction(Transactionsentity addtrans)
        {
            try
            {

                command = new SqlCommand();
                command.CommandText = "displaytop5trasactions";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;                
                command.Parameters.AddWithValue("@Account_No", addtrans.Account_No);
                connection.Open();
                SqlCommandBuilder builder = new SqlCommandBuilder();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
                sqlDataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                builder.DataAdapter = sqlDataAdapter;
                DataSet dataset = new DataSet();
                sqlDataAdapter.Fill(dataset);
                return dataset;
            }
            catch (SqlException)
            {

                throw;
            }
            catch (DetailesnotfoundException)
            {
                throw;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }

    }
}
