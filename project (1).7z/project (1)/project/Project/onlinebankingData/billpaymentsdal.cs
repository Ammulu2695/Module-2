﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingData
{
    public class billpaymentsdal
    {
        static string conStr = string.Empty;
        SqlConnection connection = null;
        SqlCommand command = null;
        static billpaymentsdal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public billpaymentsdal()
        {
            connection = new SqlConnection(conStr);
        }
        public void addbillpayments(billpayments addbill)
        {
            try
            {
                
                command = new SqlCommand();
                command.CommandText = "addbilldetails";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@phoneno", addbill.Phoneno);
                command.Parameters.AddWithValue("@mobilenetwork", addbill.Mobilenetwork);
                command.Parameters.AddWithValue("@rechargeammount", addbill.Rechargeammount);              
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (SqlException Exception)
            {

                throw Exception;
            }
            catch (billException Exception)
            {
                throw Exception;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {

                    connection.Close();
                }
            }
        }
    }
}
