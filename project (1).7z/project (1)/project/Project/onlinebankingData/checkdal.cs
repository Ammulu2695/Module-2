﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingData
{
    public class checkdal
    {
        static string conStr = string.Empty;
        SqlConnection connection = null;
        SqlCommand command = null;
        static checkdal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public checkdal()
        {
            connection = new SqlConnection(conStr);
        }
        public void addcheckdetailsdal(CheckBook addcheck)
        {
            try
            {
                
                command = new SqlCommand();
                command.CommandText = "addcheckdetails";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Account_no", addcheck.Account_no);
                command.Parameters.AddWithValue("@phoneno", addcheck.Phone_no);
                command.Parameters.AddWithValue("@address", addcheck.Address);                
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (SqlException Exception)
            {
                throw Exception;
            }
            catch (CheckbookdetailsException Exception)
            {
                throw Exception;

            }
            finally
            {
                if (connection.State == ConnectionState.Open)

                {
                    connection.Close();
                }
            }
        }


    }
}
