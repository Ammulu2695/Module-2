﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingData;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

namespace onlinebankingBusiness
{
    public class checkbookbal
    {
        // ^[0-9]{10}$
        private bool ValidateCheck(CheckBook addcheck)
        {
            bool isValidcheck = true;
            StringBuilder sbPMSError = new StringBuilder();

            if (String.IsNullOrEmpty(addcheck.Address.ToString()))
            {
                sbPMSError.Append(" Address  is  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addcheck.Account_no.ToString()))
            {
                sbPMSError.Append(" Accountno  is  Required" + Environment.NewLine);
            }
            if (!(Regex.IsMatch(addcheck.Phone_no.ToString(),"^[0-9]{10}$")))
            {
                isValidcheck = false;
                sbPMSError.Append("Phone number should be 10 digits " + Environment.NewLine);
            }
            if (!isValidcheck)

            {
                throw new CheckbookdetailsException(sbPMSError.ToString());
            }

            return isValidcheck;
        }
        public void addcheckbal(CheckBook addcheck)
        {
            try
            {
                if (ValidateCheck(addcheck))
                {
                    checkdal check = new checkdal();
                    check.addcheckdetailsdal(addcheck);

                }
                else
                {
                    throw new CheckbookdetailsException("Details not added");
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (LoandetailsnotfoundException)
            {
                throw;
            }
        }
    }
}
