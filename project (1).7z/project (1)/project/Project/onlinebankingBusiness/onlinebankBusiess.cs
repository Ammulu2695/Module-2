﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingData;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace onlinebankingBusiness
{
    public class onlinebankBusiess
    {
        private bool ValidateAccount(Account_master addnew)
        {
            bool isValidAccount = true;
            StringBuilder sbPMSError = new StringBuilder();


            if (!(Regex.IsMatch(addnew.Name, "^[A-Z][a-z]{3,}$")))
            {
                isValidAccount = false;
                sbPMSError.Append("Account holder Name must have one characters starting with uppercase " + Environment.NewLine);
            }
            if (!(Regex.IsMatch(addnew.PassWord, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$")))
            {
                isValidAccount = false;
                sbPMSError.Append("Account holder Name must have only characters starting with uppercase " + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.Name))
            {
                sbPMSError.Append("First Name Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.Account_Type))
            {
                sbPMSError.Append("Account type  Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.Email))
            {
                sbPMSError.Append("Email  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.AccountaccessMode))
            {
                sbPMSError.Append("Account access mode Name Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.Pancard_No))
            {
                sbPMSError.Append("Pancard no Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.username))
            {
                sbPMSError.Append("username  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.PassWord))
            {
                sbPMSError.Append("Password  Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.HouseAddress))
            {
                sbPMSError.Append("House address Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.Balance.ToString()))
            {
                sbPMSError.Append("Balance Required" + Environment.NewLine);
            }

            if (!isValidAccount)

            { throw new DetailesnotfoundException(sbPMSError.ToString()); }

            return isValidAccount;
        }
        private bool Validateupdatepass(Account_master addpass)
        {
            bool isValidupdatepass = true;
            StringBuilder sbPMSError = new StringBuilder();
            if (String.IsNullOrEmpty(addpass.PassWord))
            {
                sbPMSError.Append("Password  Required" + Environment.NewLine);
            }
            return isValidupdatepass;
        }
        public void AddAccountDetailsBal(Account_master addnew)
        {
            try
            {
                if (ValidateAccount(addnew))
                {
                    onlinebankdata add = new onlinebankdata();
                    add.AddAccountdetailsDal(addnew);
                }
                else
                {
                    throw new DetailesnotfoundException("Details not added");
                }

            }
            catch (SqlException Exception)
            {

                throw Exception;
            }
            catch(DetailesnotfoundException Exception)
            {
                throw Exception;
            }
        }
        public void updatepasswordbal(Account_master addnew)
        {
            try
            {
                if (Validateupdatepass(addnew))
                {
                    onlinebankdata add = new onlinebankdata();
                    add.updatepassworddal(addnew);
                }
                else
                {
                    throw new DetailesnotfoundException("Details not added");
                }

            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (DetailesnotfoundException ex)
            {
                throw ex;
            }
        }
        public void transferfundcreditbal(Account_master addammount)
        {
            try
            {
                onlinebankdata add = new onlinebankdata();
                add.updatecredit(addammount);
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (DetailesnotfoundException ex)
            {
                throw ex;
            }
        }
        public void transferfunddebitbal(Account_master addammount)
        {
            try
            {
                onlinebankdata add = new onlinebankdata();
                add.transferfunddebitdal(addammount);
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (DetailesnotfoundException ex)
            {
                throw ex;
            }
        }
        public void updatebalancebal(Account_master addbalance)
        {
            try
            {
                onlinebankdata balan = new onlinebankdata();
                balan.updatebalancedal(addbalance);
            }
            catch (SqlException Exception)
            {

                throw Exception;
            }
        }
        public Account_master displaybal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                onlinebankdata onlinebankdata = new onlinebankdata();
               master = onlinebankdata.detailsdisp(uname);
            }
            catch (Exception)
            {

                throw;
            }
            return master;
        }


        public Account_master displaytranctionbal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                onlinebankdata onlinebankdata = new onlinebankdata();
                master = onlinebankdata.displaytranction(uname);
            }
            catch (Exception)
            {

                throw;
            }
            return master;
        }
        public Account_master displayloansbal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                onlinebankdata onlinebankdata = new onlinebankdata();
                master = onlinebankdata.displayloans(uname);
            }
            catch (Exception)
            {

                throw;
            }
            return master;
        }
        public Account_master displayuserbal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                onlinebankdata onlinebankdata = new onlinebankdata();
                master = onlinebankdata.detailsuserdal(uname);
            }
            catch (Exception)
            {

                throw;
            }
            return master;
        }
        public Account_master displayaccountdetalsbal(string uname)
        {
            Account_master master = new Account_master();
            try
            {
                onlinebankdata onlinebankdata = new onlinebankdata();
                master = onlinebankdata.detailsaccountdetalsdal(uname);
            }
            catch (Exception)
            {

                throw;
            }
            return master;
        }
    }
}
