﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingData;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace onlinebankingBusiness
{
    public class Loanbal
    {
        private bool ValidateAccount(Loans addnew)
        {
            bool isValidAccount = true;
            StringBuilder sbPMSError = new StringBuilder();          
            
            if (String.IsNullOrEmpty(addnew.Applicationstatus.ToString()))
            {
                sbPMSError.Append(" Application status   is  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.DurationofLoan.ToString()))
            {
                sbPMSError.Append(" DurationofLoan  is  Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.TypeofLoan.ToString()))
            {
                sbPMSError.Append("emi amount  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.loanammount.ToString()))
            {
                sbPMSError.Append("   loan ammount is  Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.EMI.ToString()))
            {
                sbPMSError.Append("emi amount  Required" + Environment.NewLine);
            }


            if (!isValidAccount)

            {
                throw new DetailesnotfoundException(sbPMSError.ToString()); }

            return isValidAccount;
        }
        public void addloansbal(Loans addloan)
        {
            try
            {
                if (ValidateAccount(addloan))
                {
                    LoanDal loanDal = new LoanDal();
                    loanDal.addLoandetails(addloan);

                }
                else
                {
                    throw new LoandetailsnotfoundException("Details not added");
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch(LoandetailsnotfoundException)
            {
                throw;
            }
        }
        public Loans displayloanbal(string accountno)
        {
            Loans loans = new Loans();
            try
            {
                LoanDal loanDal = new LoanDal();
                loans = loanDal.detailsloans(accountno);
            }
            catch (Exception)
            {

                throw;
            }
            return loans;
        }
    }
}
