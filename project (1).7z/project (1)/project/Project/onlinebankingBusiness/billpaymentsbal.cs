﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using onlinebankingData;
using onlinebankingentitys;
using onlinebankingexception;

namespace onlinebankingBusiness
{
    public class billpaymentsbal
    {


        // ^[0-9]{10}$
        private bool ValidateCheck(billpayments addbill)
        {
            bool isValidcheck = true;
            StringBuilder sbPMSError = new StringBuilder();

            if (String.IsNullOrEmpty(addbill.Mobilenetwork.ToString()))
            {
                sbPMSError.Append(" mobilenetwork  is  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addbill.Rechargeammount.ToString()))
            {
                sbPMSError.Append(" rechargeammount  is  Required" + Environment.NewLine);
            }
            if (!(Regex.IsMatch(addbill.Phoneno.ToString(), "^[0-9]{10}$")))
            {
                isValidcheck = false;
                sbPMSError.Append("Phone number should be 10 digits " + Environment.NewLine);
            }
            if (!isValidcheck)

            {
                throw new CheckbookdetailsException(sbPMSError.ToString());
            }

            return isValidcheck;
        }
        public void addbillball(billpayments addbills)
        {
            try
            {
                if (ValidateCheck(addbills))
                {
                    billpaymentsdal bill = new billpaymentsdal();
                    bill.addbillpayments(addbills);

                }
                else
                {
                    throw new CheckbookdetailsException("Details not added");
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (billException)
            {
                throw;
            }
        }
    }
}
