﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingData;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace onlinebankingBusiness
{
    public class TransactionBal
    {
        private bool ValidateAccount(Transactionsentity addnew)
        {
            bool isValidAccount = true;
            StringBuilder sbPMSError = new StringBuilder();         
            if (String.IsNullOrEmpty(addnew.DateofTransaction.ToString()))
            {
                sbPMSError.Append(" date of transaction  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.TypeofTransaction))
            {
                sbPMSError.Append(" type  of transaction Required" + Environment.NewLine);
            }

            if (String.IsNullOrEmpty(addnew.amount.ToString()))
            {
                sbPMSError.Append("amount  Required" + Environment.NewLine);
            }
            if (String.IsNullOrEmpty(addnew.Account_No.ToString()))
            {
                sbPMSError.Append("   Account no  Required" + Environment.NewLine);
            }
            
            

            if (!isValidAccount)

            { throw new DetailesnotfoundException(sbPMSError.ToString()); }

            return isValidAccount;
        }



        private bool Validatedate(Transactionsentity adddate)
        {
            bool isValiddate = true;
            StringBuilder sbPMSError = new StringBuilder();
            if (String.IsNullOrEmpty(adddate.DateofTransaction.ToString()))
            {
                sbPMSError.Append(" date of transaction  Required" + Environment.NewLine);
            }
            if (!isValiddate)

            { throw new DetailesnotfoundException(sbPMSError.ToString()); }

            return isValiddate;
        }

        private bool Validatetoptrans(Transactionsentity addtrans)
        {
            bool isValidtoptrans = true;
            StringBuilder sbPMSError = new StringBuilder();
            if (String.IsNullOrEmpty(addtrans.Account_No.ToString()))
            {
                sbPMSError.Append(" date of transaction  Required" + Environment.NewLine);
            }
            if (!isValidtoptrans)

            { throw new DetailesnotfoundException(sbPMSError.ToString()); }

            return isValidtoptrans;
        }




        public void addTransactionbal(Transactionsentity addnew)
        {
            try
            {
                if (ValidateAccount(addnew))
                {
                    TransactionDal transaction = new TransactionDal();
                    transaction.addTransactiondetails(addnew);
                    
                }
                else
                {
                    throw new DetailesnotfoundException("Details not added");
                }
            }
            catch (SqlException)
            {

                throw;
            }

        }

        public DataSet addsearchdate(Transactionsentity adddate)
        {
            try
            {
                if (Validatedate(adddate))
                {
                    TransactionDal transactionDal = new TransactionDal();
                    transactionDal.searchthroughdate(adddate);
                    DataSet dataset = new DataSet();
                    dataset = transactionDal.searchthroughdate(adddate);
                    return dataset;
                    //connection.Open();
                }
                else
                {
                    throw new DetailesnotfoundException("Transaction not done");
                }
            }
            catch (Exception)
            {

                throw;
            }
           

        }


        public DataSet top5transationbal(Transactionsentity addtrans)
        {
            try
            {
                if (Validatetoptrans(addtrans))
                {
                    TransactionDal transactionDal = new TransactionDal();
                    transactionDal.top5transaction(addtrans);
                    DataSet dataset = new DataSet();
                    dataset = transactionDal.top5transaction(addtrans);
                    return dataset;
                    //connection.Open();
                }
                else
                {
                    throw new DetailesnotfoundException("Transaction not done");
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (DetailesnotfoundException Ex)
            {
                throw Ex;
            }


        }


    }
}
