﻿using System;

namespace onlinebankingentity
{
    public class Class1
    {
    }
}
