﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingexception
{

    [Serializable]
    public class billException : Exception
    {
        public billException() { }
        public billException(string message) : base(message) { }
        public billException(string message, Exception inner) : base(message, inner) { }
        protected billException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
