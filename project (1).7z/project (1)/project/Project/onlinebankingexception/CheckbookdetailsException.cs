﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingexception
{

    [Serializable]
    public class CheckbookdetailsException : Exception
    {
        public CheckbookdetailsException() { }
        public CheckbookdetailsException(string message) : base(message) { }
        public CheckbookdetailsException(string message, Exception inner) : base(message, inner) { }
        protected CheckbookdetailsException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
