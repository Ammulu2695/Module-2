﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingexception
{

    [Serializable]
    public class LoandetailsnotfoundException : Exception
    {
        public LoandetailsnotfoundException() { }
        public LoandetailsnotfoundException(string message) : base(message) { }
        public LoandetailsnotfoundException(string message, Exception inner) : base(message, inner) { }
        protected LoandetailsnotfoundException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
    }
}
