﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using System.Data;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Tranction.xaml
    /// </summary>
    public partial class Tranction : Window
    {
       // int bal1;
        string uname;
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand cmd= new SqlCommand();
        public Tranction()
        {
            InitializeComponent();
        }
        public Tranction(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {                 
            displaydetalis();
        }
        public void displaydetalis()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displaytranctionbal(uname);
                
                txtaccountnumber.Text = master.Account_No.ToString();
                txtbalance.Text = master.Balance.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Account_master accountcredit = new Account_master();
                accountcredit.Account_No = int.Parse(txtaccountno.Text);
                accountcredit.Balance = int.Parse(txtamount.Text);
                
                Account_master accountdebit = new Account_master();
                accountdebit.Account_No = int.Parse(txtaccountnumber.Text);
                accountdebit.Balance = int.Parse(txtbalance.Text);
                accountdebit.x = int.Parse(txtaccountno.Text);
                accountdebit.y = int.Parse(txtamount.Text);
                Balancedebit(accountdebit);
                onlinebankBusiess newbalance = new onlinebankBusiess();
                newbalance.transferfundcreditbal(accountcredit);
                newbalance.transferfunddebitbal(accountdebit);
                MessageBox.Show("Transfer sucessfully");
                reset();

            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            catch(DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public void reset()
        {
            txtamount.Text = "";
            txtaccountno.Text = "";
        }
        
        public void Balancedebit(Account_master accountdebit)
        {
            //txtbalance.Text = txtbalance.Text - txtamount.Text;
            int c, d;
            c = int.Parse(txtbalance.Text);
            d = int.Parse(txtamount.Text);
            c = c - d;
            accountdebit.Balance = c;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Accountdetails accountdetails = new Accountdetails(uname);
            accountdetails.Show();
            this.Close();
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
