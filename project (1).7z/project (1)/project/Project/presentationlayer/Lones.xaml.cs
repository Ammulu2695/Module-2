﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;
using System.Data;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Lones.xaml
    /// </summary>
    public partial class Lones : Window
    {
        string uname;
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command;
        public Lones()
        {
            InitializeComponent();
        }
        public Lones(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void btnapply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Loans loans = new Loans();
                loans.LoanID = int.Parse(txtloanid.Text);
                loans.AccountID = int.Parse(txtAccountid.Text);
                loans.TypeofLoan = cbtypeoflone.Text;
                loans.loanammount = double.Parse(txtloanamount.Text);
                loans.DurationofLoan = int.Parse(txtdurationofloan.Text);
               // loans.EMI = double.Parse(txtemi.Text);
                loans.Applicationstatus = cbapplicationstatus.Text;

                Loanbal loandetails = new Loanbal();
                loandetails.addloansbal(loans);
                MessageBox.Show("Registration sucessful");
                Reset();
            }
            catch (LoandetailsnotfoundException Exception)
            {

                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            loanidautoincrement();
            accountnodisp();
           
        }
        public void Reset()
        {
            cbtypeoflone.Text = "";
            txtloanamount.Text = "";
            txtdurationofloan.Text = "";
            cbapplicationstatus.Text = "";
        }
        public void loanidautoincrement()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                command = new SqlCommand("select ident_current('ProjectLoan_172311')+ident_incr('ProjectLoan_172311')", connection);
                connection.Open();
                object nextloanid = command.ExecuteScalar();
                txtloanid.Text = nextloanid.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            catch (DetailesnotfoundException Exception)
            {

                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }      
        public void accountnodisp()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displayloansbal(uname);
                
                txtAccountid.Text = master.Account_No.ToString();
                
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string accountno = txtAccountid.Text;
            Loanstatus loanstatus = new Loanstatus(accountno,uname);
            loanstatus.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Homepage homepage = new Homepage(uname);
            homepage.Show();
            this.Close();
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
