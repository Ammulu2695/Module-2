﻿using onlinebankingBusiness;
using onlinebankingentitys;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Billpayments.xaml
    /// </summary>
    public partial class Billpayments : Window
    {
        string uname;
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public Billpayments()
        {
            InitializeComponent();
            
        }
        public Billpayments(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }
        public void displaydetalis()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displaytranctionbal(uname);

                txtaccountno.Text = master.Account_No.ToString();
                txtbalance.Text = master.Balance.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            Homepage homepage = new Homepage(uname);
            homepage.Show();
            this.Close();
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            displaydetalis();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            claculate();
            Account_master account = new Account_master();
            account.Balance = int.Parse(txtbalance.Text);
            account.Account_No = int.Parse(txtaccountno.Text);
            onlinebankBusiess bal = new onlinebankBusiess();
            bal.updatebalancebal(account);
            billpayments bill = new billpayments();
            bill.Phoneno = long.Parse(txtphoneno.Text);
            bill.Mobilenetwork = cbmobilenetwork.Text;
            bill.Rechargeammount = int.Parse(txtrechargeamount.Text);
            billpaymentsbal bills = new billpaymentsbal();
            bills.addbillball(bill);
            MessageBox.Show("Recharge sucessfully Done");
            Reset();
        }
        public void claculate()
        {
            int a = int.Parse(txtbalance.Text);
            int b = int.Parse(txtrechargeamount.Text);
            int c;
            c = a - b;
            txtbalance.Text = c.ToString();
        }
        public void Reset()
        {
            txtphoneno.Text = "";
            txtrechargeamount.Text = "";
            cbmobilenetwork.Text = "";
        }

    }
}
