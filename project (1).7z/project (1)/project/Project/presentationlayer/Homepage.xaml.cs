﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Homepage.xaml
    /// </summary>
    public partial class Homepage : Window
    {
        string uname;
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public Homepage()
        {
            InitializeComponent();
        }
        public Homepage(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void Accountdetails_Click(object sender, RoutedEventArgs e)
        {
            Accountdetails accdetails = new Accountdetails(uname);
            accdetails.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {           
            displayuserdetalis();
        }
        public void displayuserdetalis()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displayuserbal(uname);
                txtname.Text = master.Name;
                txtAccountno.Text = master.Account_No.ToString();
                txtbalance.Text = master.Balance.ToString();
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public void loadgrid()
        {
            try
            {               
                Transactionsentity transactionsentity = new Transactionsentity
                {
                    DateofTransaction = Convert.ToDateTime(datepicker.Text),
                    Account_No = Convert.ToInt32(txtAccountno.Text)
                };
                TransactionBal hotel = new TransactionBal();
                DataSet dataset = hotel.addsearchdate(transactionsentity);                
                dgsearchdatevise.DataContext = dataset.Tables[0];                
           }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            catch(DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        private void butsearch_Click(object sender, RoutedEventArgs e)
        {
            loadgrid();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Lones lones = new Lones(uname);
            lones.Show();
            this.Close();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Billpayments billpayments = new Billpayments(uname);
            billpayments.Show();
            this.Close();
        }
    }
}
