﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Registrationform.xaml
    /// </summary>
    public partial class Registrationform : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command;


        public Registrationform()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Account_master account_Master = new Account_master();
                account_Master.Account_No = int.Parse(txtAccount_No.Text);
                account_Master.Account_Type = cbAccount_Type.Text;
                account_Master.Name = txtName.Text;
                account_Master.Email = txtEmail.Text;
                account_Master.HouseAddress = txtAddress.Text;
                account_Master.Pancard_No = txtpancard.Text;
                account_Master.AccountaccessMode = cbAccountaccessmode.Text;
                account_Master.username = txtusername.Text;
                account_Master.PassWord = txtpassword.Password;
                account_Master.Balance =int.Parse(txtbalance.Text);
                account_Master.OpeningDate = DateTime.Parse(dtopening.Text); 
                if(txtpassword.Password.ToString() == txtconfirmpassword.Password.ToString())
                {
                    onlinebankBusiess newaccount = new onlinebankBusiess();
                    newaccount.AddAccountDetailsBal(account_Master);
                    MessageBox.Show("Registration sucessful");
                    accountincrement();
                    Reset();
                    //this.Close();

                }
            }
            catch(SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            catch (DetailesnotfoundException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            accountincrement();
        }
        public void accountincrement()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                command = new SqlCommand("select ident_current('ProjectAccountMaster_172311')+ident_incr('ProjectAccountMaster_172311')", connection);
                connection.Open();
                object nextAccountno = command.ExecuteScalar();
                txtAccount_No.Text = nextAccountno.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            catch (DetailesnotfoundException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void butreset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        public void Reset()
        {
            txtAddress.Text = "";
            txtbalance.Text = "";
            txtconfirmpassword.Password = "";
            txtEmail.Text = "";
            txtName.Text = "";
            txtpancard.Text = "";
            txtpassword.Password = "";
            txtusername.Text = "";
            cbAccountaccessmode.Text = "";
            cbAccount_Type.Text = "";
            dtopening.Text = "";

        }

        private void butlogin_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
