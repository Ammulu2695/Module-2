﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;
using System.Data;
using System.Data.SqlClient;


namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Checkbook.xaml
    /// </summary>
    public partial class Checkbook : Window
    {
        string uname;
        public Checkbook()
        {
            InitializeComponent();
        }
        public Checkbook(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            Accountdetails accountdetails = new Accountdetails(uname);
            accountdetails.Show();
            this.Close();
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CheckBook checkbook = new CheckBook();
                checkbook.Account_no = long.Parse(txtaccountno.Text);
                checkbook.Phone_no = long.Parse(txtphoneno.Text);
                checkbook.Address = txtaddress.Text;
                checkbookbal check = new checkbookbal();
                check.addcheckbal(checkbook);
                MessageBox.Show("Request sent sucessful");
                Reset();
            }
            catch (CheckbookdetailsException Exception)
            {

                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }

        }
        public void displayaccount()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displayloansbal(uname);

                txtaccountno.Text = master.Account_No.ToString();

            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            displayaccount();
        }
        public void Reset()
        {
            txtphoneno.Text = "";
            txtaddress.Text = "";
        }
    }
}
