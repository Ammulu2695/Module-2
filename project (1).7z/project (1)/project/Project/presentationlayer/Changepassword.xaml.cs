﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Changepassword.xaml
    /// </summary>
    public partial class Changepassword : Window
    {
        string uname;
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command;
        public Changepassword()
        {
            InitializeComponent();
        }
        public Changepassword(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void txtchgpass_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Account_master account_Master = new Account_master();
                account_Master.username = txtuname.Text;
                account_Master.PassWord = txtnewpassword.Password;
                if (txtnewpassword.Password.ToString() == txtconfirmnewpass.Password.ToString())
                {
                    onlinebankBusiess newaccount = new onlinebankBusiess();
                    newaccount.updatepasswordbal(account_Master);
                    MessageBox.Show("Your Password has been updated sucessful");
                    this.Close();
                    MainWindow main = new MainWindow();
                    main.Show();


                }            
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            catch(DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void butback_Click(object sender, RoutedEventArgs e)
        {
            Accountdetails accountdetails = new Accountdetails(uname);
            accountdetails.Show();
            this.Close();
        }

        private void txtlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
