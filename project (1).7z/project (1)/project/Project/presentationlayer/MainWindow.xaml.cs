﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
       // SqlCommand command;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var Registrationform = new Registrationform();
            Registrationform.ShowDialog();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                string query = "select username,PassWord from ProjectAccountMaster_172311 where username = '" + txtuname.Text + "' and PassWord = '" + txtpassword.Password + "'";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter da = new SqlDataAdapter(command);

                DataTable dt = new DataTable();
               // DataSet data = new DataSet();

                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Login successfully");
                    string uname = txtuname.Text;
                    Homepage homepage = new Homepage(uname);

                    homepage.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Incorrect username and password");
                }
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            catch (DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        
    }
}
