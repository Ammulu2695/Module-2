﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using System.Data;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Transactions.xaml
    /// </summary>
    public partial class Transactions : Window
    {
        string uname;
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        public Transactions()
        {
            InitializeComponent();
        }
        public Transactions(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtdate.Text = DateTime.Now.ToString();
            transactionincreament();
            //detailsdisp();
            displaydetalis();

        }
        public void transactionincreament()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                command = new SqlCommand("select ident_current('ProjectTransactions_172311')+ident_incr('ProjectTransactions_172311')", connection);
                connection.Open();
                object nextTransactionid = command.ExecuteScalar();
                txttransactionid.Text = nextTransactionid.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception occured" + Exception.Message);
            }
            catch (DetailesnotfoundException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }
        }


   

            public void displaydetalis()
            {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displaybal(uname);
                txtname.Text = master.Name;
                txtAccountno.Text = master.Account_No.ToString();
                txtbalance.Text = master.Balance.ToString();
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
            finally
            {
                connection.Close();
            }

        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Transactionsentity trans = new Transactionsentity();
                trans.Account_No = int.Parse(txtAccountno.Text);
                trans.Transaction_ID = int.Parse(txttransactionid.Text);
                trans.DateofTransaction = DateTime.Parse(txtdate.Text);
                trans.TypeofTransaction = cbtypeoftransaction.Text;
                trans.amount = int.Parse(txtamount.Text);
                if(cbtypeoftransaction.Text== "WithDraw")
                {
                    int a,b;
                    a = int.Parse(txtamount.Text);
                    b = int.Parse(txtbalance.Text);
                    b = b - a;
                    txtbalance.Text = b.ToString();
                  
                } 
                else if(cbtypeoftransaction.Text== "Deposit")
                {
                    int a, b;
                    a = int.Parse(txtamount.Text);
                    b = int.Parse(txtbalance.Text);
                    b = b + a;
                    txtbalance.Text = b.ToString();
                 
                }
                else if(cbtypeoftransaction.Text == "DD")
                {
                    int a, b;
                    a = int.Parse(txtamount.Text);
                    b = int.Parse(txtbalance.Text);
                    b = b - a;
                    txtbalance.Text = b.ToString();
                    
                }
                TransactionBal transactionBal = new TransactionBal();
                transactionBal.addTransactionbal(trans);


                Account_master account = new Account_master();
                account.Balance = int.Parse(txtbalance.Text);
                account.Account_No = int.Parse(txtAccountno.Text);
                onlinebankBusiess bal = new onlinebankBusiess();
                bal.updatebalancebal(account);
                MessageBox.Show("Transaction sucessfully");
               
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception occured" + Exception.Message);
            }
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            Accountdetails account = new Accountdetails(uname);
            account.Show();
            this.Close();
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
