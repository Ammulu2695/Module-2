﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Accountdetails.xaml
    /// </summary>
    public partial class Accountdetails : Window
    {
        string uname;
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command = new SqlCommand();
        public Accountdetails()
        {
            InitializeComponent();
        }
        public Accountdetails(string _uname)
        {
            InitializeComponent();
            uname = _uname;
        }

        private void btnchanpass_Click(object sender, RoutedEventArgs e)
        {
            Changepassword chanpass = new Changepassword(uname);
            chanpass.Show();
            this.Close();

        }

        private void btntransaction_Click(object sender, RoutedEventArgs e)
        {

            Tranction tranction = new Tranction(uname);
            tranction.Show();
            this.Close();

        }

        private void btntransactions_Click(object sender, RoutedEventArgs e)
        {
            Transactions transactions = new Transactions(uname);
            transactions.Show();
            this.Close();
            
        }
        public void loadgrid()
        {
            try
            {               
                Transactionsentity transactionsentity = new Transactionsentity
                {                    
                    Account_No = Convert.ToInt32(txtaccountno.Text)
                };
                TransactionBal  transactionBal = new TransactionBal();
                DataSet dataset = transactionBal.top5transationbal(transactionsentity);
                dgviewaccountdetails.DataContext = dataset.Tables[0];
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            catch(DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        public void accountnodisp()
        {
            try
            {
                onlinebankBusiess onlinebank = new onlinebankBusiess();
                Account_master master = new Account_master();
                master = onlinebank.displayaccountdetalsbal(uname);

                txtaccountno.Text = master.Account_No.ToString();
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            catch(DetailesnotfoundException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            accountnodisp();
            loadgrid();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Homepage homepage = new Homepage(uname);
            homepage.Show();
            this.Close();
        }

        private void txtlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }

        private void btncheckreq_Click(object sender, RoutedEventArgs e)
        {
            Checkbook checkbook = new Checkbook(uname);
            checkbook.Show();
            this.Close();
               
        }
    }
}
