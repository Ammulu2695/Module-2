﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using onlinebankingentitys;
using onlinebankingexception;
using onlinebankingBusiness;
using System.Data;

namespace presentationlayer
{
    /// <summary>
    /// Interaction logic for Loanstatus.xaml
    /// </summary>
    public partial class Loanstatus : Window
    {
        string accountno, uname;
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand command;
        public Loanstatus()
        {
            InitializeComponent();
        }
        public Loanstatus(string _accountno,string _uname)
        {
            InitializeComponent();
            accountno = _accountno;
            uname = _uname;
        }
        

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            disploanstatus();
        }
        public void disploanstatus()
        {
            try
            {              
                Loanbal loanbal = new Loanbal();
                Loans loans = new Loans();
                loans = loanbal.displayloanbal(accountno);
                txtloanid.Text = loans.LoanID.ToString();
                txtAccountid.Text = loans.AccountID.ToString();
                txttypeofloan.Text = loans.TypeofLoan;
                txtloanamount.Text = loans.loanammount.ToString();
                txtdurationofloan.Text = loans.DurationofLoan.ToString();
                txtemi.Text = loans.EMI.ToString();
                txtApplicationstatus.Text = loans.Applicationstatus;
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        private void btnlogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnback_Click(object sender, RoutedEventArgs e)
        {
            Lones lones = new Lones(uname);
            lones.Show();
            this.Close();
        }
    }
}
