﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingentitys
{
    class Facilities
    {
        public int Facility_Id { get; set; }
        public string TypeofFacility { get; set; }
    }
}
