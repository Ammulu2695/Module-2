﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingentitys
{
    public class Transactionsentity
    {
        public int Transaction_ID { get; set; }
        public DateTime DateofTransaction { get; set; }
        public string TypeofTransaction { get; set; }
        public int Account_No { get; set; }
        public int amount { get; set; }
    }
}
