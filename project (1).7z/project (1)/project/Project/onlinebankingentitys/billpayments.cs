﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingentitys
{
    public class billpayments
    {
        public long Phoneno { get; set; }
        public string Mobilenetwork { get; set; }
        public int Rechargeammount { get; set; }

    }
}
