﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingentitys
{
    public class Loans
    {
        public int LoanID { get; set; }
        public int AccountID { get; set; }
        public string TypeofLoan { get; set; }
        public double loanammount { get;set; }
        public double DurationofLoan { get; set; }
        public double EMI { get; set; }
        public string Applicationstatus{ get; set; }
    }
}
