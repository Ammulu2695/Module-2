﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlinebankingentitys
{
    public class Account_master
    {
        public int Account_No { get; set; }
        public string Account_Type { get; set; }
        public int Balance { get; set; }
        public DateTime OpeningDate{ get; set; }
       
        public string Name { get; set; }
        public string Email { get; set; }
        public string HouseAddress { get; set; }
        public string Pancard_No { get; set; }
        public string AccountaccessMode { get; set; }
        public string  username { get; set; }
        public string PassWord { get; set; }
        public int x { get; set; }
        public int y { get; set; }
    }
}
