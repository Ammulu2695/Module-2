﻿CREATE PROCEDURE displaytop5trasactions
	(
	@Account_No bigint
	
	)
AS
begin
	select top(5)*  from ProjectTransactions_172311 where Account_No=@Account_No  order by Transaction_ID   desc
end
