﻿create PROCEDURE disp (
@username varchar(50)
)
AS
begin
	select * from ProjectAccountMaster_172311 where username = @username

RETURN 
end
