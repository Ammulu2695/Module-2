﻿CREATE PROCEDURE display5(
	@AccountID bigint

)	
AS
begin
	SELECT * from ProjectLoan_172311 where AccountID = @AccountID
end