﻿CREATE PROCEDURE disp(
	@username varchar(50)

)	
AS
begin
	SELECT Name,Balance,Account_No from ProjectAccountMaster_172311 where username=@username
end