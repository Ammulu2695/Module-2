create table ProjectAccountMaster_172311
(
Account_No bigint Identity(100000000,1) primary key,
Account_Type varchar(50),
Balance int,
Opening_Date date,
Name varchar(50),
Email varchar(50),
HouseAddress nvarchar(max),
Pancard_no varchar(50),
AccountaccessMode varchar(50) 

)


select * from ProjectAccountMaster_172311


ALTER TABLE ProjectAccountMaster_172311
ADD username varchar(50);
alter table ProjectAccountMaster_172311
add PassWord varchar(50);
alter table ProjectAccountMaster_172311
drop table ProjectAccountMaster_172311


create table ProjectTransactions_172311
(
Transaction_ID bigint Identity(600000,1) primary key,
DateofTransaction date,
TypeofTransaction varchar(50),
Account_No bigint foreign key references ProjectAccountMaster_172311 (Account_No),

)
alter table ProjectTransactions_172311
add amount int;
drop table ProjectTransactions_172311

 select * from  ProjectTransactions_172311

 select top(5)*  from ProjectTransactions_172311 where Account_No=100000001  order by Transaction_ID   desc


 select Account_No,Balance from ProjectAccountMaster_172311 where 100000000



 CREATE PROCEDURE displayaccoutandbalance (
@username varchar(50)
	)
AS
begin
	select Account_No,Balance from ProjectAccountMaster_172311 where username=@username

RETURN 
end




create table ProjectLoan_172311(
LoanID  bigint Identity(800000,1) primary key,
 AccountID bigint foreign key references ProjectAccountMaster_172311 (Account_No),
 TypeofLoan varchar(50),

 loanammount bigint,
 DurationofLoan  float,
 EMI float,
 Applicationstatus varchar(50)
)

drop table ProjectLoan_172311
select * from ProjectLoan_172311


create table Projectcheck_172311
(
Account_no bigint foreign key references ProjectAccountMaster_172311 (Account_No),
phoneno bigint,
address varchar(50)
)

select * from Projectcheck_172311