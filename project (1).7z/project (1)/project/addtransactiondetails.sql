﻿CREATE Procedure AddTransactiondetails
(

@DateofTransaction date,
@TypeofTransaction varchar(50),
@Account_No bigint ,
@amount int
)
As
Begin
insert into ProjectTransactions_172311(
  DateofTransaction ,TypeofTransaction ,Account_No ,amount 
)
values (
 @DateofTransaction ,@TypeofTransaction ,@Account_No ,@amount )
end