﻿CREATE PROCEDURE disp1(
	@username varchar(50)

)	
AS
begin
	SELECT Account_No,Balance from ProjectAccountMaster_172311 where username=@username
end