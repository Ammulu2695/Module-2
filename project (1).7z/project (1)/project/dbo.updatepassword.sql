﻿create procedure updatepassword(
@username varchar(50),
@PassWord varchar(50)

)
as
begin
update ProjectAccountMaster_172311 set PassWord=@PassWord where username=@username
end