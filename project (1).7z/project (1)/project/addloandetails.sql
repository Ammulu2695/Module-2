﻿create procedure addloandetails
(

 @AccountID bigint ,
 @TypeofLoan varchar(50),

 @loanammount bigint,
 @DurationofLoan  float,
 @EMI bigint,
 @Applicationstatus varchar(50)
)
as
begin
insert into ProjectLoan_172311( AccountID ,TypeofLoan ,loanammount ,DurationofLoan  ,EMI ,Applicationstatus )
values (@AccountID,@TypeofLoan,@loanammount,@DurationofLoan,@EMI,@Applicationstatus)
end