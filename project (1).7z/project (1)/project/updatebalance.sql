﻿CREATE PROCEDURE updateBalancecredit(
	@Account_No int,
	@Balance int
	)
AS
begin
	update ProjectAccountMaster_172311
	set Balance = Balance + (@Balance)
	where Account_No = @Account_No
end
