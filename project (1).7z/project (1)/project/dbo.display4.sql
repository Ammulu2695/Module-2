﻿CREATE PROCEDURE display4(
	@username varchar(50)

)	
AS
begin
	SELECT Account_No from ProjectAccountMaster_172311 where username=@username
end