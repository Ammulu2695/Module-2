DECLARE @Var1 INT
DECLARE @Var2 INT

SET @Var1 = 1
SET @Var2 = 2

SELECT @Var1 'Var1', @Var2 'Var2'
GO