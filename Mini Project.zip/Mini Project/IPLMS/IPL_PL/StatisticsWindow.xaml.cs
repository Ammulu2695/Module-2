﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for StatisticsWindow.xaml
    /// </summary>
    public partial class StatisticsWindow : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public StatisticsWindow()
        {
            InitializeComponent();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow main1 = new LinkWindow(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Statistics p = new Statistics
                {
                    TeamId = int.Parse(txtTeamId.Text),
                    NetRunRate = float.Parse(txtnetrrate.Text),
                    NetRequiredRunRate = float.Parse(txtrrr.Text),
                    ForAgainst = txtForAgainest.Text,
                    From = txtFrom1.Text,
                    status = comboBoXUserType.Text,
                    Played = string.Empty
                   
                };
                if (rbyes.IsChecked == true)
                {
                    //Played == rbyes.Content.ToString();
                }
                

                StatisticsBal pb = new StatisticsBal();
                //int pid = pb.AddStatisticsBAL(p);
                //MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", pid),
                //    "Product Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

       
            //txtStatus.Visibility = Visibility.Visible;
            //comboBoXUserType.Visibility = Visibility.Visible;
            
        

        
            //txtStatus.Visibility = Visibility.Hidden;
            //comboBoXUserType.Visibility = Visibility.Hidden;
        

        
    }
}
