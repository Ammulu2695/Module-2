﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using IPLEntities;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();

        public MainWindow()
        {
            InitializeComponent();
        }

        

        


        private void button1_Click(object sender, RoutedEventArgs e)
        {
            
                if (comboBoXUserType.Text == "Admin")
                {

                    Admin_Add admin = new Admin_Add(); //create your new form.
                    admin.Show(); //show the new form.
                    this.Close();
                }
                else if(comboBoXUserType.Text == "Customer")
                {
                try
                {
                    string query = "select UserName,Password from [IPL].[RegisterDetails] Where"
                        + "UserName='" + textBoxUserName.Text + "' and Password='" + passwordBox1.Password + "'";
                    SqlCommand cmd= new SqlCommand(query,connection);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count >= 0)
                    {
                        //MessageBox.Show("Login Successful");
                        //Register_User admin = new Register_User();
                        //admin.Show();
                        //this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                    }

                }
                catch (SqlException)
                {
                    throw;
                }
                finally
                {
                   connection.Close();
                }
            }

            
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {

            Register main1 = new Register(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
