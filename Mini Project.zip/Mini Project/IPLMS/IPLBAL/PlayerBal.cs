﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class PlayerBal
    {

        StringBuilder sb = new StringBuilder();
        private bool ValidatePlayer(Players pro)
        {


            bool IsValidPlayer = true;
            if (pro.PlayerId.ToString().Equals(string.Empty))
            {
                IsValidPlayer = false;
                sb.Append("PlayerId cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.PlayerId.ToString(), @"^[a-zA-Z]+$").Success)
            {
                IsValidPlayer = false;
                sb.Append(Environment.NewLine + "PlayerId should be Alphabets");
            }
            if (pro.TeamId.ToString().Equals(string.Empty))
            {
                IsValidPlayer = false;
                sb.Append("TeamId cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.TeamId.ToString(), @"^[a-zA-Z]+$").Success)
            {
                IsValidPlayer = false;
                sb.Append(Environment.NewLine + "TeamId should be Alphabets");
            }
            //if (!(Regex.IsMatch(pro.TeamId.ToString(), @"[0-9]$")))
            //{
            //    IsValidPlayer = false;
            //    sb.Append(Environment.NewLine + "TeamId should greater than zero");
            //}

            if (pro.Name.Equals(string.Empty))
            {
                IsValidPlayer = false;
                sb.Append("Name cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.Name, @"^[a-zA-Z]+$").Success)
            {
                IsValidPlayer = false;
                sb.Append(Environment.NewLine + "Name should be Alphabets Only");
            }
            
            if (pro.Age < 10)
            {
                IsValidPlayer = false;
                sb.Append(Environment.NewLine + "Age should be greater than 10");
            }
            if (pro.Age.Equals(string.Empty))
            {
                IsValidPlayer = false;
                sb.Append("Age cannot be blank " + Environment.NewLine);

            }
            if (pro.Speciality.Equals(string.Empty))
            {
                IsValidPlayer = false;
                sb.Append("Speciality cannot be blank " + Environment.NewLine);

            }
            return IsValidPlayer;
        }
        //AddPlayerBAL
        public int AddPlayerBAL(Players pobj)
        {
            try
            {
                int pid = 0;
                PlayerDal pd = new PlayerDal();
                if (ValidatePlayer(pobj))
                {
                    pid = pd.AddPlayerDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //DisplayPlayerBal
        public DataTable DisplayPlayerBal()
        {
            try
            {
                PlayerDal sd = new PlayerDal();
                DataTable dtProduct = sd.DisplayPlayerDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Player Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //UpdatePlayerBal
        public bool UpdatePlayerBal(Players upmatch)
        {
            bool Playerupdated = false;
            try
            {
                if (ValidatePlayer(upmatch))
                {
                    PlayerDal matchda = new PlayerDal();//give Dal class 
                    Playerupdated = matchda.UpdatePlayerDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Playerupdated;

        }
        //DeletePlayerBAL
        public static bool DeletePlayerBAL(string PlayerId)
        {
            bool PlayerDeleted = false;
            try
            {
                PlayerDal deletedal = new PlayerDal();
                PlayerDeleted = deletedal.DeletePlayerDAL(PlayerId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return PlayerDeleted;
        }
    }
}
