﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using IPL_DAL;
using System.Data;
using System.Data.SqlClient;

namespace IPLBAL
{
    public class Roles_bal
    {
        //AddRolesbal

        StringBuilder sb = new StringBuilder();
        private bool ValidateRole(Roles pro)
        {


            bool IsValidRoll = true;
            if (pro.RoleId < 1)
            {
                IsValidRoll = false;
                sb.Append(Environment.NewLine + "RoleId should not be negative");
            }

            if (pro.RoleId.Equals(string.Empty))
            {
                IsValidRoll = false;
                sb.Append("RoleId cannot be blank " + Environment.NewLine);

            }
            if (pro.RoleName.Equals(string.Empty))
            {
                IsValidRoll = false;
                sb.Append("RoleName cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.RoleName, @"^[A-Z,a-z]*$").Success)
            {
                IsValidRoll = false;
                sb.Append(Environment.NewLine + "RoleName should contain Characters Only");
            }

          
            return IsValidRoll;
        }
        public int AddRolesbal(Roles pobj)
        {
            try
            {
                int pid = 0;
                Roles_dal pd = new Roles_dal();
                if (ValidateRole(pobj))
                {
                    pid = pd.AddRolesDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        public DataTable ViewRolesBal()
        {
            try
            {
                Roles_dal sd = new Roles_dal();
                DataTable dtProduct = sd.ViewRolesDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Roles Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    
        public bool UpdateRolesBal(Roles upmatch)
        {
            bool Matchupdated = false;
            try
            {
                if (ValidateRole(upmatch))
                {
                    Roles_dal matchdal = new Roles_dal();//give Dal class 
                    Matchupdated = matchdal.UpdateRolesDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Matchupdated;

        }
    }
}