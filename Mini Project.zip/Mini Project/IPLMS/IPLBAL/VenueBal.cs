﻿using IPL_DAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace IPLBAL
{
    public class VenueBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateVenue(Venue pro)
        {


            bool IsValidVenue = true;
            if (pro.VenueId.ToString().Equals(string.Empty))
            {
                IsValidVenue = false;
                sb.Append("VenueId cannot be blank " + Environment.NewLine);

            }
            if (pro.Location.Equals(string.Empty))
            {
                IsValidVenue = false;
                sb.Append("Location cannot be blank " + Environment.NewLine);

            }
            if (pro.Description.Equals(string.Empty))
            {
                IsValidVenue = false;
                sb.Append("Description cannot be blank " + Environment.NewLine);

            }
            if (!Regex.Match(pro.Location, @"^[a-zA-Z]+$").Success)
            {
                IsValidVenue = false;
                sb.Append(Environment.NewLine + "Location should be Alphabets");
            }
            if (pro.VenueId < 1)
            {
                IsValidVenue = false;
                sb.Append(Environment.NewLine + "VenueId should not be negative");
            }
            return IsValidVenue;
        }
        //VenueBAL
        public int AddVenueBAL(Venue pobj)
        {
            try
            {
                int pid = 0;
                VenueDAL pd = new VenueDAL();
                if (ValidateVenue(pobj))
                {
                    pid = pd.AddVenueDal(pobj);
                }
                else
                    throw new IPLException(sb.ToString());

                return pid;
            }
            catch (IPLException)
            {
                throw;
            }
        }
        //DisplayVenueBal
        public DataTable DisplayVenueBal()
        {
            try
            {
                VenueDAL sd = new VenueDAL();
                DataTable dtProduct = sd.DisplayVenueDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new IPLException("No Student Available");
                }
                return dtProduct;
            }
            catch (IPLException se)
            {
                throw se;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        //update
        public bool UpdateVenueBal(Venue upmatch)
        {
            bool Venueupdated = false;
            try
            {
                if (ValidateVenue(upmatch))
                {
                    VenueDAL matchdal = new VenueDAL();
                    Venueupdated = matchdal.UpdatevenueDal(upmatch);
                }
            }
            catch (IPLExceptions.IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Venueupdated;

        }
        //delete
        //DeleteVenuePL
        public static bool DeleteVenuePL(string VenueId)
        {
            bool VenueDeleted = false;
            try
            {
                VenueDAL deletehoteldal = new VenueDAL();
                VenueDeleted = deletehoteldal.DeleteVenueDAL(VenueId);
            }
            catch (IPLException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return VenueDeleted;
        }
    }
}
