﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class PlayerDal
    {
        //AddPlayerDal
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static PlayerDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public PlayerDal()
        {
            con = new SqlConnection(conStr);
        }
        //Add Product
        public int AddPlayerDal(Players pboj)
        {
            int pid = 0;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Player_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", pboj.PlayerId);
                cmd.Parameters.AddWithValue("@TeamId", pboj.TeamId);
                cmd.Parameters.AddWithValue("@PlayerName", pboj.Name);
                cmd.Parameters.AddWithValue("@PlayerAge", pboj.Age);
                cmd.Parameters.AddWithValue("@PlayerSpeciality", pboj.Speciality);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //DisplayPlayerDal
        public DataTable DisplayPlayerDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Player_Display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //UpdatePlayerDal
        public bool UpdatePlayerDal(Players pbo)
        {
            bool isemployeeedited = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Player_update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", pbo.PlayerId);
                cmd.Parameters.AddWithValue("@TeamId", pbo.TeamId);
                cmd.Parameters.AddWithValue("@PlayerName", pbo.Name);
                cmd.Parameters.AddWithValue("@PlayerAge", pbo.Age);
                cmd.Parameters.AddWithValue("@PlayerSpeciality", pbo.Speciality);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        //DeletePlayerDAL
        public bool DeletePlayerDAL(string PlayerId)
        {
            bool VenueDeleted = false;
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Player_Delete]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@PlayerId", PlayerId);
                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    VenueDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return VenueDeleted;
        }
    }
}
