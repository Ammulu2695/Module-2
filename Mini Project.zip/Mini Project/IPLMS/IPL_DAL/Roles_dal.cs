﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
   public class Roles_dal
   {
        //AddRolesDal
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static Roles_dal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public Roles_dal()
        {
            con = new SqlConnection(conStr);
        }
        public int AddRolesDal(Roles pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Roles_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                //cmd.Parameters.Add("@SerialNumber", SqlDbType.Int);
                //cmd.Parameters["@SerialNumber"].Direction = ParameterDirection.Output;


                cmd.Parameters.AddWithValue("@RoleId", pboj.RoleId);
                cmd.Parameters.AddWithValue("@RoleName", pboj.RoleName);
               

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
                pid = pid + 1;
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }

        public DataTable ViewRolesDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Roles_display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //update
        //UpdateRolesDal
        public bool UpdateRolesDal(Roles pbo)
        {
            bool isemployeeedited = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Roles__Update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@RoleId",pbo.RoleId);
                cmd.Parameters.AddWithValue("@RoleName", pbo.RoleName);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
    }
}
