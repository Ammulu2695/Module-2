﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public  class TeamDal
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static TeamDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public TeamDal()
        {
            con = new SqlConnection(conStr);
        }
        //AddTeamDal
        public int AddTeamDal(Team pboj)
        {
            int pid = 0;
            try
            {
               
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Team_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TeamId", pboj.TeamId);
                cmd.Parameters.AddWithValue("@TeamName", pboj.TeamName);
                cmd.Parameters.AddWithValue("@HomeGround", pboj.HomeGround);
                cmd.Parameters.AddWithValue("@Owner", pboj.Owner);
                cmd.Parameters.AddWithValue("@LogoImage", pboj.LogoImage);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //UpdateTeamDal
        public bool UpdateTeamDal(Team pbo)
        {
            bool isemployeeedited = false;
            try
            {   cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Team_update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TeamId", pbo.TeamId);
                cmd.Parameters.AddWithValue("@TeamName", pbo.TeamName);
                cmd.Parameters.AddWithValue("@HomeGround", pbo.HomeGround);
                cmd.Parameters.AddWithValue("@Owner", pbo.Owner);
                cmd.Parameters.AddWithValue("@LogoImage", pbo.LogoImage);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        //DeleteTeamDAL
        public bool DeleteTeamDAL(string TeamId)
        {
            bool VenueDeleted = false;
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Team_delete]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@TeamId", TeamId);

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    VenueDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return VenueDeleted;
        }
        //DisplayTeamBal
        public DataTable DisplayTeamDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Team_display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
