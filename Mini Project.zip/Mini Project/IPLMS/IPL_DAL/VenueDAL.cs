﻿using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL_DAL
{
    public class VenueDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static VenueDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public VenueDAL()
        {
            con = new SqlConnection(conStr);
        }

        //AddVenueDal
        public int AddVenueDal(Venue pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Venue_Add]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VenueId",pboj.VenueId);
                cmd.Parameters.AddWithValue("@Location", pboj.Location);
                cmd.Parameters.AddWithValue("@Description", pboj.Description);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                //pid = int.Parse(cmd.Parameters["@SerialNumber"].Value.ToString());
            }
            catch (IPLException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
        //DisplayVenueDal
        public DataTable DisplayVenueDal()
        {
            DataTable dt = null;


            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Venue_display]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;


                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        //UpdatevenueDal
        public bool UpdatevenueDal(Venue pbo)
        {
            bool isemployeeedited = false;
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Venue_Update]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@VenueId", pbo.VenueId);
                cmd.Parameters.AddWithValue("@Location", pbo.Location);
                cmd.Parameters.AddWithValue("@Description", pbo.Description);
               
                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();

                if (noOfRowsAffected == 1)
                    isemployeeedited = true;
            }
            catch (IPLExceptions.IPLException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        //delete
        public bool DeleteVenueDAL(string VenueId)
        {
            bool VenueDeleted = false;
            try
            {
                con.Open();
                cmd = new SqlCommand();
                cmd.CommandText = "[IPL].[Venue_Delete]";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
               
                cmd.Parameters.AddWithValue("@VenueId", VenueId);

                int NumberOfRowsdeleted = cmd.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    VenueDeleted = true;
            }
            catch (Exception ex)
            {
                throw new IPLException(ex.Message);
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return VenueDeleted;
        }
    }
}
