﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPL_PL
{
    /// <summary>
    /// Interaction logic for Schedule.xaml
    /// </summary>
    public partial class Schedule : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        //SqlCommand cmdObj;
        //SqlParameter parmObj;
        //SqlDataReader rdrStudent = null;
        DataTable dtStudent = new DataTable();
        public Schedule()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SchedulEntity p = new SchedulEntity
                {
                    ScheduleId= int.Parse(txtScheduleId1.Text),
                    MatchId=int.Parse(txtMatchId1.Text),
                    VenueId=int.Parse(txtVenueId1.Text),
                    Date=DateTime.Parse(DatePick.Text),
                    StartTime=DateTime.Parse(txtStartTime1.Text),
                    EndTime=DateTime.Parse(txtEndTime1.Text)
                };

                ScheduleBal pb = new ScheduleBal();
                int pid = pb.AddScheduleBAL(p);
                MessageBox.Show(string.Format("New Schedule Added"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "IPL Management System");
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            
            View_Schedule main1 = new View_Schedule(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }

        //update
        private static void UpdateSchedule(SchedulEntity editemp)
        {

            try
            {
                ScheduleBal pb = new ScheduleBal();
                bool Scheduleedited = pb.UpdateScheduleBal(editemp);
                if (Scheduleedited)
                {
                    MessageBox.Show("Schedule Updated Successfully");

                }
                else
                    MessageBox.Show("Schedule not updated");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            SchedulEntity type = new SchedulEntity();

            type.ScheduleId = int.Parse(txtScheduleId1.Text);
            type.MatchId= int.Parse(txtMatchId1.Text);
            type.VenueId = int.Parse(txtVenueId1.Text);
            type.StartTime= DateTime.Parse(txtStartTime1.Text);
            type.EndTime = DateTime.Parse(txtEndTime1.Text);
            type.Date = DateTime.Parse(DatePick.Text);

            UpdateSchedule(type);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int ScheduleId = Int32.Parse(txtScheduleId1.Text);
            try
            {
                bool ScheduleDeleted = ScheduleBal.DeleteScheduleBAL(ScheduleId.ToString());

                if (ScheduleDeleted)
                    MessageBox.Show("Schedule Deleted successfully");
                else
                    MessageBox.Show("Schedule not Deleted");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message);
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            LinkWindow n = new LinkWindow(); //create your new form.
            n.Show(); //show the new form.
            this.Close();
        }
    }
}
