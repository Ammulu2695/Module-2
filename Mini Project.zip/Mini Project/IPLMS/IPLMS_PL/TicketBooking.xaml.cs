﻿using IPLBAL;
using IPLEntities;
using IPLExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IPLMS_PL
{
    /// <summary>
    /// Interaction logic for TicketBooking.xaml
    /// </summary>
    public partial class TicketBooking : Window
    {
        public TicketBooking()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                BookingEntity p = new BookingEntity
                {
                    Id= int.Parse(textId.Text),
                    FirstName= textFirstName.Text,
                    LastName= textLastName.Text,
                    Age= int.Parse(textAge.Text),
                    NumberofTickets = int.Parse(textNoofTickets.Text),
                };

                BookingBAL pb = new BookingBAL();
                int pid = pb.AddBookingBAL(p);
                MessageBox.Show(string.Format("Your Tickets Are Booked"),
                    "IPL Management System");
            }
            catch (IPLException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        //private void Hyperlink_Click(object sender, RoutedEventArgs e)
        //{

        //    Customer main1 = new Customer(); //create your new form.
        //    main1.Show(); //show the new form.
        //    this.Close();
        //}

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Customer main1 = new Customer(); //create your new form.
            main1.Show(); //show the new form.
            this.Close();
        }
    }
}
