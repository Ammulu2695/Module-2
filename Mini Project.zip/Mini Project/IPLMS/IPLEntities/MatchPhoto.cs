﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class MatchPhoto
    {
        //MatchPhoto: Id, MatchId, Photo
        public int MatchPhotoId { get; set; }
        public int MatchId { get; set; }
        public byte[] Photo { get; set; }

    }
}
