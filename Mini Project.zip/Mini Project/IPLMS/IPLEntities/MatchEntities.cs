﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPLEntities
{
    public class MatchEntities
    {
        //Id, TeamOneId, TeamTwoId, VenueId, ScheduleId, PhotoGroupId
        public int MatchId { get; set; }
        public int TeamOneId { get; set; }
        public int TeamTwoId { get; set; }
        public int VenueId { get; set; }
        public int ScheduleId { get; set; }
        public int PhotoGroupId { get; set; }

    }
}
