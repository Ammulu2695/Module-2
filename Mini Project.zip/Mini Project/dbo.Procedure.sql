﻿CREATE PROCEDURE [IPL].[Users_display]
AS
Begin
	SELECT * from [IPL].[Users]
end
